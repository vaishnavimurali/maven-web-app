/* eslint-disable no-unreachable */
/**
=========================================================
* Material Dashboard 2 React - v2.1.0
=========================================================

* Product Page: https://www.creative-tim.com/product/material-dashboard-react
* Copyright 2022 Creative Tim (https://www.creative-tim.com)

Coded by www.creative-tim.com

 =========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
*/

// Material Dashboard 2 React example components
import React from "react";
import DashboardLayout from "components/LayoutContainers/DashboardLayout";
import MDBox from "components/MDBox";
import MDTypography from "components/MDTypography";
import { Oval } from "react-loading-icons";

import { useMaterialUIController } from "context";

import colors from "assets/theme/base/colors";

function Mission() {
  const [controller] = useMaterialUIController();
  const { authState } = controller;

  if (!authState) {
    return (
      <DashboardLayout headerTitle="SSB Mission">
        <Oval
          stroke={colors.exelixis}
          style={{ marginLeft: 10, marginTop: 3, position: "absolute" }}
        />
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout headerTitle="SSB Mission">
      <MDBox display="flex" justifyContent="center" alignItems="center">
        <MDBox p={10} alignItems="center" style={{ maxWidth: 1300 }}>
          {/* Header */}
          <MDTypography
            variant="h1"
            align="center"
            fontWeight="regular"
            color="text"
            style={{ marginBottom: 20 }}
          >
            Scientific Strategy Bioinformatics Mission Statement
          </MDTypography>
          <MDTypography align="left" fontWeight="regular" color="text" style={{ marginBottom: 20 }}>
            The Scientific Strategy Bioinformatics team is dedicated to delivering impactful data
            analysis services for Exelixis. Our mission is to provide comprehensive analyses that
            encompass target evaluation, mechanism of action and disease process elucidation,
            indication discovery, and patient selection. Through our work, we aim to positively
            influence program decisions and expand Exelixis’s ‘omics based understanding of cancer.
          </MDTypography>
          <MDTypography align="left" fontWeight="regular" color="text" style={{ marginBottom: 20 }}>
            We strive to make analysis results easily accessible and foster a culture of
            understanding through our user-friendly portals. Our focus is on creating exceptional
            user experiences, offering highly extensible visualizations and methods, and developing
            knowledge-capturing interfaces for both bioinformaticians and researchers.
          </MDTypography>
          <MDTypography align="left" fontWeight="regular" color="text" style={{ marginBottom: 20 }}>
            As part of our responsibilities, we manage data procurement, which involves evaluating
            vendors, cultivating vendor relationships, and overseeing pilot projects. We collaborate
            closely with stakeholders to define data onboarding policies that support our goals.
          </MDTypography>
          <MDTypography align="left" fontWeight="regular" color="text" style={{ marginBottom: 20 }}>
            Scientific Strategy Bioinformatics takes the lead in designing and specifying solutions
            for a robust data and computing platform dedicated to bioinformatics analysis. We work
            hand in hand with our Information Technology partners to develop a platform that adheres
            to FAIR principles (Findable, Accessible, Interoperable, and Reusable). Our platform
            ensures reliable microservice-driven APIs for data access and compute, while being
            flexible, performant, and scalable to accommodate diverse data types and computation
            methods.
          </MDTypography>
          <MDTypography align="left" fontWeight="regular" color="text" style={{ marginBottom: 20 }}>
            Accomplishments-to-date:
            <br />
            <ol>
              <li>
                Program and research impacts:
                <ul style={{ marginLeft: 40 }}>
                  <li>
                    Identified the CXCL12-CXCR4 axis and its connection to cabozantinib effects in
                    Renal Cell Carcinoma using Tempus data. The X4 CXCR4 small molecule antagonist
                    mavorixafor was tested alone and in combination with cabozantinib and
                    zanzalintinib in the RCC 786-O xenograft model. Addition of CXCR4i to TKIs may
                    provide additive benefit, especially to cabozantinib, while the treatment
                    effects of the CXCR4 inhibitor outperformed and were dominant to zanzalintinib
                    alone and in combination.
                  </li>
                  <li>
                    Characterized the biology of macrophage subsets expressing each of the five
                    BioInvent collaboration targets.
                  </li>
                  <li>Identified the coexpression of CA9 with ENPP3.</li>
                </ul>
              </li>
              <li>
                Data and tools:
                <ul style={{ marginLeft: 40 }}>
                  <li>
                    Established Exelixis&apos;s Areti and Elastic Beaker platforms, prioritizing
                    robust and time-resilient knowledge representation.
                  </li>
                  <li>Launched GeneLens, a valuable tool for data exploration.</li>
                  <li>
                    Successfully onboarded data sources such as Reactome, Gene Ontology, ChEA
                    transcription factors, BioGrid, Tempus RCC, and TCGA survival analysis results.
                    New software tools and a more efficient pipeline have been developed which will
                    allow increased onboarding (up to six datasets per month).
                  </li>
                  <li>
                    Initiated the onboarding process for CPTAC, TCGA, study-specific data, and scRNA
                    data.
                  </li>
                  <li>Collaborated with BISC to launch scRNA cell subtype clusters work.</li>
                </ul>
              </li>
            </ol>
          </MDTypography>
          <MDTypography align="left" fontWeight="regular" color="text" style={{ marginBottom: 20 }}>
            By continuously advancing our capabilities and leveraging innovative technologies, the
            Scientific Strategy Bioinformatics team remains committed to delivering exceptional data
            analysis services and contributing to the scientific achievements of Exelixis.
          </MDTypography>
        </MDBox>
      </MDBox>
    </DashboardLayout>
  );
}

export default Mission;

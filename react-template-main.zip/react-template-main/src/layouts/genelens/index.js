/**
=========================================================
* Material Dashboard 2 React - v2.1.0
=========================================================

* Product Page: https://www.creative-tim.com/product/material-dashboard-react
* Copyright 2022 Creative Tim (https://www.creative-tim.com)

Coded by www.creative-tim.com

 =========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
*/

import React, { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";

import { useOktaAuth } from "@okta/okta-react";

// Material Dashboard 2 React components
import MDBox from "components/MDBox";
import MDTypography from "components/MDTypography";
import Modal from "@mui/material/Modal";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import IconButton from "@mui/material/IconButton";
import Snackbar from "@mui/material/Snackbar";
import Alert from "@mui/material/Alert";
import CloseIcon from "@mui/icons-material/Close";

// Material Dashboard 2 React example components
import DashboardLayout from "components/LayoutContainers/DashboardLayout";
import colorsLight from "assets/theme/base/colors";
import colorsDark from "assets/theme-dark/base/colors";

import { Oval } from "react-loading-icons";

import useClipboardApi from "use-clipboard-api";

import Icon from "@mui/material/Icon";
import { GetGeneFromSymbol } from "apiWrapper";
import { useMaterialUIController } from "context";
import { Card } from "@mui/material";
import useLocalStorage from "hooks/UseLocalStorage";
import SurvivalPlotting from "./components/SurvivalPlotting";
import GeneSummary from "./components/GeneSummary";
import SurvivalSearch from "./components/SurvivalSearch";
import SearchResults from "./components/SearchResults";
import GeneHeatmap from "./components/GeneHeatmap";

const isLocal = process.env.REACT_APP_LOCAL === "true";

function GeneLens() {
  const { authState, oktaAuth } = useOktaAuth();

  const [cbValue, copy] = useClipboardApi();
  const [openUrlNotif, setOpenUrlNotif] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);
  const [searchParams] = useSearchParams();

  const [rows, setRows] = useState([[], []]);

  const [primaryGene, setPrimaryGene] = useState(null);
  const [secondaryGene, setSecondaryGene] = useState(null);
  const [indication, setIndication] = useState(searchParams.get("indication") || null);

  const [rowID, setRowID] = useState("");
  const [chartsOpen, setChartsOpen] = useState(false);
  const [requiredCharts, setRequiredCharts] = useState([]);

  const [authHeader, setAuthHeader] = useState();

  const [openFeedbackHelp, setOpenFeedbackHelp] = useLocalStorage("feedback-helped", false);

  const [controller] = useMaterialUIController();
  const { darkMode } = controller;

  const colors = darkMode ? colorsDark : colorsLight;

  useEffect(() => {
    if (!authState || !authState.isAuthenticated) {
      // When user isn't authenticated, forget any user info
      setAuthHeader(null);
    } else {
      setAuthHeader(`Bearer ${authState.accessToken.accessToken}`);
    }
  }, [authState, oktaAuth]); // Update if authState changes

  useEffect(() => {
    const GetSearchParamGene = (param, setGene) => {
      const geneName = searchParams.get(param);
      if (geneName) {
        GetGeneFromSymbol(geneName).then((gene) => {
          if (gene) setGene(gene);
        });
      }
    };

    GetSearchParamGene("gene_1", setPrimaryGene);
    GetSearchParamGene("gene_2", setSecondaryGene);
  }, []);

  const handleChartsOpen = (row) => {
    let currentRequiredCharts = [];
    if (row.type === "surv.exp.mut" || row.type === "exp.mut") {
      currentRequiredCharts = [
        "chart_exp_all",
        "chart_exp_mut",
        "chart_exp",
        "chart_mut",
        "chart_split",
      ];
    } else if (row.type === "surv.exp.all") {
      currentRequiredCharts = ["chart_exp_all"];
    } else if (row.type === "surv.mut") {
      currentRequiredCharts = ["chart_mut"];
    }

    setRequiredCharts(currentRequiredCharts);
    setRowID(row.id);
    setChartsOpen(true);
  };

  const handleChartsClose = () => {
    setRequiredCharts([]);
    setRowID("");
    setChartsOpen(false);
  };

  return (
    <DashboardLayout
      headerTitle="GeneLens (beta)"
      headerButtons={[
        {
          effect: () => setHelpOpen(true),
          icon: "question_mark",
          toolTip: "Help",
        },
        {
          effect: () => {
            copy(window.location.href);
            setOpenUrlNotif(true);
          },
          icon: "share",
          toolTip: "Share",
        },
      ]}
    >
      {/* Floating Components */}
      <>
        {/* Chart Display */}
        {(isLocal || (authState && authHeader)) && (
          <Modal
            id="survival-charts-modal"
            open={chartsOpen}
            onClose={handleChartsClose}
            aria-labelledby="modal-charts"
          >
            <MDBox sx={{ pointerEvents: "none" }}>
              <SurvivalPlotting rowID={rowID} chartNames={requiredCharts} authHeader={authHeader} />
            </MDBox>
          </Modal>
        )}
        {/* Help */}
        <Dialog
          open={helpOpen}
          onClose={() => setHelpOpen(false)}
          aria-labelledby="customized-dialog-title"
          sx={{
            position: "absolute",
            color: "#000000",
          }}
          PaperComponent={Card}
        >
          <DialogTitle id="customized-dialog-title" onClose={() => setHelpOpen(false)}>
            GeneLens Help
            <IconButton
              aria-label="close"
              onClick={() => setHelpOpen(false)}
              sx={{
                position: "absolute",
                right: 8,
                top: 8,
                color: (theme) => theme.palette.grey[500],
              }}
            >
              <CloseIcon />
            </IconButton>
          </DialogTitle>
          <hr
            style={{
              height: 1,
              width: "90%",
              margin: "auto",
              backgroundColor: colors.inputBorderColor,
              color: colors.transparent.main,
            }}
          />
          <DialogContent>
            <MDTypography
              variant="button"
              fontSize="large"
              fontWeight="regular"
              color="text"
              mr={3}
            >
              Search for genes here. You can search by a primary gene, a secondary gene, or both.
              The primary gene maps to gene expression (Gene E in the first table) and mutation
              (Gene M in the secondary table). The secondary gene maps to Gene E in the second table
              and Gene M in the primary table. Thus we can see interactions between the genes in
              their associations with survival. The indications selector restricts matches to data
              from a specific disease indication. To see only the survival dependencies on gene
              expression levels for a gene, with no interaction analysis, click the &quot;ONLY
              SURV.EXP.ALL&quot; button.
            </MDTypography>
          </DialogContent>
        </Dialog>
        {/* URL Copy */}
        <Snackbar
          message={cbValue || ""}
          color="secondary"
          anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
          onClose={() => setOpenUrlNotif(false)}
          open={openUrlNotif}
          autoHideDuration={2000}
        />
        <Snackbar
          anchorOrigin={{ vertical: "top", horizontal: "right" }}
          open={!openFeedbackHelp}
          autoHideDuration={5000}
          onClose={() => {
            setOpenFeedbackHelp(true);
          }}
          sx={{ mt: 10 }}
        >
          <Alert
            severity="info"
            color="secondary"
            variant="filled"
            action={
              <IconButton
                aria-label="close"
                color="inherit"
                size="small"
                onClick={() => {
                  setOpenFeedbackHelp(true);
                }}
              >
                <Icon>close</Icon>
              </IconButton>
            }
          >
            Have some ideas or a bug to report? Click{" "}
            <Icon color="inherit" baseClassName="material-icons-outlined">
              feedback
            </Icon>{" "}
            above to submit feedback!
          </Alert>
        </Snackbar>
      </>
      {/* GeneLens Body */}
      {isLocal || (authState && authHeader) ? (
        <MDBox pb={3} pt={6} id="genelens-body">
          {/* Header */}
          <SurvivalSearch
            setRows={setRows}
            authHeader={authHeader}
            primaryGene={primaryGene}
            setPrimaryGene={setPrimaryGene}
            secondaryGene={secondaryGene}
            setSecondaryGene={setSecondaryGene}
            indication={indication}
            setIndication={setIndication}
          />
          <GeneSummary
            geneID={primaryGene?.entrez_id}
            name={primaryGene?.name}
            symbol={primaryGene?.symbol}
            secondarySymbol={secondaryGene?.symbol}
            geneAliases={[
              ...(primaryGene?.alias_symbol ? primaryGene.alias_symbol.split("|") : ""),
              ...(primaryGene?.prev_symbol ? primaryGene.prev_symbol.split("|") : ""),
            ]}
          />
          {primaryGene && secondaryGene && (
            <GeneSummary
              geneID={secondaryGene?.entrez_id}
              name={secondaryGene?.name}
              symbol={secondaryGene?.symbol}
              secondarySymbol={primaryGene?.symbol}
              geneAliases={[
                ...(secondaryGene?.alias_symbol ? secondaryGene.alias_symbol.split("|") : ""),
                ...(secondaryGene?.prev_symbol ? secondaryGene.prev_symbol.split("|") : ""),
              ]}
            />
          )}
          <SearchResults
            rows={rows}
            handleChartsOpen={handleChartsOpen}
            primaryGene={primaryGene}
            setPrimaryGene={setPrimaryGene}
            secondaryGene={secondaryGene}
            setSecondaryGene={setSecondaryGene}
          />
          <GeneHeatmap geneSymbol={primaryGene?.symbol} />
          <GeneHeatmap geneSymbol={secondaryGene?.symbol} />
        </MDBox>
      ) : (
        <MDBox py={3}>
          <Oval
            stroke={colors.exelixis}
            style={{ marginLeft: 10, marginTop: 3, position: "absolute" }}
          />
        </MDBox>
      )}
    </DashboardLayout>
  );
}

export default GeneLens;

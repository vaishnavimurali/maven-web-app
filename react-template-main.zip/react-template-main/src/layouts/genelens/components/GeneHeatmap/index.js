import React, { useState } from "react";
import PropTypes from "prop-types";

import MDBox from "components/MDBox";
import MDTypography from "components/MDTypography";

import {
  Heatmap,
  HeatmapSeries,
  LinearXAxis,
  LinearXAxisTickSeries,
  LinearXAxisTickLabel,
} from "reaviz";

import sampleData from "assets/data/report4.json";
import { Card } from "@mui/material";
import MDButton from "components/MDButton";

sampleData.heatmapM = [];

sampleData["sample.classes"][0].set.forEach((item, i) => {
  sampleData.heatmapM[i] = { key: item, data: { key: "", data: "" } };
});

sampleData.heatmapNM = [];

sampleData["sample.classes"][1].set.forEach((item, i) => {
  sampleData.heatmapNM[i] = { key: item, data: { key: "", data: "" } };
});

function GeneHeatmap(props) {
  const { geneSymbol } = props;
  const [hmGradient, setHmGradient] = useState(["#ff0000", "#0000ff"]);
  const [hmGradient2, setHmGradient2] = useState(["#ff0000", "#0000ff"]);

  const metastasisIndex = sampleData["data.matrix"].geneSymbolIndex[geneSymbol];

  const setHMGradient = () => {
    /* eslint-disable */
    function dev(arr){
      // Creating the mean with Array.reduce
      let mean = arr.reduce((acc, curr)=>{
        return acc + curr
      }, 0) / arr.length;

      // Assigning (value - mean) ^ 2 to every array item
      arr = arr.map((k)=>{
        return (k - mean) ** 2
      })

      // Calculating the sum of updated array
     let sum = arr.reduce((acc, curr)=> acc + curr, 0);

     // Calculating the variance
     let variance = sum / arr.length

     // Returning the Standered deviation
     return Math.sqrt(sum / arr.length)
    }

    // console.log(sampleData.heatmapM[0].data);

    // let biggestABS = 0;
    let msHigh = 0;
    let msLow = 0;
    let nmsHigh = 0;
    let nmsLow = 0;

    const msData = [];
    // console.log(sampleData["results.table"][metastasisIndex]["p.value"] < 0.01);
    sampleData["data.matrix"].data[metastasisIndex].forEach((item, i) => {
      let itemValue = sampleData["data.matrix"].data[metastasisIndex][i];
      msData.push(itemValue);
      // biggestABS = biggestABS < Math.abs(itemValue) ? Math.abs(itemValue) : biggestABS;
    });
    // msData.sort((a, b) => a - b);
    const average = msData.reduce((a, b) => a + b) / msData.length;
    const gradientStops = 25;
    const gradient = [];
    const gradient2 = [];
    let zNorm = 0;
    for (let i = 0; i < gradientStops; i += 1) {
      let rgba = "";
      if (i < 11) {
        zNorm = (sampleData.heatmapM[i].data[0].data - average) / dev(msData);
        // console.log(sampleData.heatmapM[i]);
        if (zNorm > msHigh) msHigh = zNorm;
        if (zNorm < msLow) msLow = zNorm;
      } else {
        zNorm = (sampleData.heatmapNM[i - 11].data[0].data - average) / dev(msData);
        if (zNorm > nmsHigh) nmsHigh = zNorm;
        if (zNorm < nmsLow) nmsLow = zNorm;
        // console.log(sampleData.heatmapNM[i]);
      }

      // zNorm *= 1.5;
      // console.log(zNorm);
      if (zNorm > 0) {
        // console.log("red to white");
        // console.log("Original Data: ", msData[i]);
        // console.log("zNorm: ", zNorm, i + 1);
        const red = Math.round(255 * (zNorm / 4) < 256 ? 255 * (zNorm / 4) : 255);
        // console.log("red: ", red);
        const greenBlue = 255 - red;
        // console.log("greenBlue: ", greenBlue);
        rgba = `rgba(255,${greenBlue},${greenBlue},1)`;
      } else {
        // console.log("white to blue");
        // console.log("Original Data: ", msData[i]);
        // console.log("zNorm: ", zNorm, i + 1);
        const blue = Math.round(255 * Math.abs(zNorm / 4) < 256 ? 255 * Math.abs(zNorm / 4) : 255);
        // console.log("blue: ", blue);
        const greenRed = 255 - blue;
        // console.log("greenRed: ", greenRed);
        rgba = `rgba(${greenRed},${greenRed},255,1)`;
      }
      /*
      if (i < 11) {
        gradient[i] = rgba;
      } else {
        gradient2[i - 11] = rgba;
      }
      */
    }

    for (let i = 40 * (1-(Math.abs(msLow)/4)); i < (40*(msHigh/4)) + 40; i += 1) {
      let rgba = "";
      zNorm = (i - 39.5)/10;
      if (zNorm > 0) {
        const red = Math.round(255 * (zNorm / 4) < 256 ? 255 * (zNorm / 4) : 255);
        const greenBlue = 255 - red;
        rgba = `rgba(255,${greenBlue},${greenBlue},1)`;
      } else {
        const blue = Math.round(255 * Math.abs(zNorm / 4) < 256 ? 255 * Math.abs(zNorm / 4) : 255);
        const greenRed = 255 - blue;
        rgba = `rgba(${greenRed},${greenRed},255,1)`;
      }
      gradient.push(rgba);
      //gradient2.push(rgba);
    }

    for (let i = 40 * (1-(Math.abs(nmsLow)/4)); i < (40*(nmsHigh/4)) + 40; i += 1) {
      let rgba = "";
      zNorm = (i - 39.5)/10;
      if (zNorm > 0) {
        const red = Math.round(255 * (zNorm / 4) < 256 ? 255 * (zNorm / 4) : 255);
        const greenBlue = 255 - red;
        rgba = `rgba(255,${greenBlue},${greenBlue},1)`;
      } else {
        const blue = Math.round(255 * Math.abs(zNorm / 4) < 256 ? 255 * Math.abs(zNorm / 4) : 255);
        const greenRed = 255 - blue;
        rgba = `rgba(${greenRed},${greenRed},255,1)`;
      }
      //gradient.push(rgba);
      gradient2.push(rgba);
    }

    // console.log(gradient);
    // console.log(gradient2);
    // console.log(sampleData.heatmapM[0].data.data);
    // console.log(sampleData.heatmapNM);

    if (JSON.stringify(gradient) !== JSON.stringify(hmGradient)) {
      setHmGradient(gradient);
      setHmGradient2(gradient2);
    }
    /* eslint-enable */
  };

  if (metastasisIndex) {
    sampleData["data.matrix"].data[metastasisIndex].forEach((item, i) => {
      if (i < 11) {
        sampleData.heatmapM[i].data = [];
        sampleData.heatmapM[i].data[0] = {
          key: geneSymbol,
          data: sampleData["data.matrix"].data[metastasisIndex][i],
        };
      } else {
        sampleData.heatmapNM[i - 11].data = [];
        sampleData.heatmapNM[i - 11].data[0] = {
          key: geneSymbol,
          data: sampleData["data.matrix"].data[metastasisIndex][i],
        };
      }
    });
    setHMGradient();
  }

  return (
    metastasisIndex &&
    sampleData["results.table"][metastasisIndex]["p.value"] < 0.01 && (
      <div id={`${geneSymbol}-heatmap`}>
        <MDBox display="flex" sx={{ pb: 2 }} width="100%">
          <MDTypography variant="h4" fontWeight="regular" color="text" mr={3}>
            {geneSymbol} metastasis in clear cell renal cell carcinoma analysis (P-Value:{" "}
            {sampleData["results.table"][metastasisIndex]["p.value"].toPrecision(2)})
          </MDTypography>
          <MDBox marginLeft="auto">
            <MDButton
              color="info"
              variant="outlined"
              href="https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE66270"
              target="_blank"
              rel="noreferrer"
            >
              Study Link
            </MDButton>
          </MDBox>
        </MDBox>
        <Card sx={{ p: 3 }}>
          <MDBox display="flex">
            <MDBox sx={{ width: 0.44 }}>
              <MDTypography variant="h5" fontWeight="regular" color="text" ml={6}>
                Metastatic
              </MDTypography>
              <Heatmap
                height={170}
                margins={50}
                data={sampleData.heatmapM}
                series={<HeatmapSeries animated={false} colorScheme={hmGradient} />}
                xAxis={
                  <LinearXAxis
                    type="category"
                    tickSeries={
                      <LinearXAxisTickSeries label={<LinearXAxisTickLabel rotation={-45} />} />
                    }
                  />
                }
              />
            </MDBox>
            <MDBox sx={{ width: 0.56 }}>
              <MDTypography variant="h5" fontWeight="regular" color="text" ml={4}>
                Non-Metastatic
              </MDTypography>
              <Heatmap
                height={170}
                margins={50}
                data={sampleData.heatmapNM}
                series={<HeatmapSeries animated={false} colorScheme={hmGradient2} />}
                xAxis={
                  <LinearXAxis
                    type="category"
                    tickSeries={
                      <LinearXAxisTickSeries label={<LinearXAxisTickLabel rotation={-45} />} />
                    }
                  />
                }
              />
            </MDBox>
          </MDBox>
        </Card>
        <br />
      </div>
    )
  );
}
GeneHeatmap.propTypes = {
  geneSymbol: PropTypes.string,
};
GeneHeatmap.defaultProps = {
  geneSymbol: "",
};
export default GeneHeatmap;

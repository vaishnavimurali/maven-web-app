import React, { useEffect, useState } from "react";
import PropTypes from "prop-types";

import MDBox from "components/MDBox";
import MDTypography from "components/MDTypography";
import MDButton from "components/MDButton";
import logo from "assets/images/exelixis-logo.png";
import { GetGeneSummary } from "apiWrapper";
import { Card } from "@mui/material";

function GeneSummary(props) {
  const [summary, setSummary] = useState("");
  const { geneID, name, symbol, secondarySymbol, geneAliases } = props;

  useEffect(() => {
    if (geneID === "-1") {
      setSummary("");
      return;
    }

    GetGeneSummary(geneID).then((newSummary) => setSummary(newSummary));
  }, [geneID]);

  const studyLinks = {
    "NCBI Gene": `https://www.ncbi.nlm.nih.gov/gene/${geneID}`,
    "Dep Map": `https://depmap.org/portal/gene/${symbol}?tab=overview`,
    "cBio Portal": `https://www.cbioportal.org/ln?q=${symbol}`,
    "Uni Prot": `https://www.uniprot.org/uniprotkb?query=(gene:${symbol})%20AND%20(taxonomy_id:9606)`,
    "Protein Atlas": `https://www.proteinatlas.org/search/${symbol}`,
    PubMed: `https://pubmed.ncbi.nlm.nih.gov/?from_uid=${geneID}&linkname=gene_pubmed`,
    PMC: `https://www.ncbi.nlm.nih.gov/pmc?LinkName=gene_pmc&from_uid=${geneID}`,
  };

  const discoDashLinks = {
    "SL Dashboard": `https://discodash.discovery-bioinformatics.aws-exelixis.com/sl-dashboard?gene=${symbol}&target_gene=${secondarySymbol}`,
    "Cell Line Dependence": `https://discodash.discovery-bioinformatics.aws-exelixis.com/cell-line-dependence-on-rnai-plot?gene=${symbol}&target_gene=${secondarySymbol}`,
    "Gene Expression": `https://discodash.discovery-bioinformatics.aws-exelixis.com/gene-expression-vs-tissue-type-plot?gene=${symbol}`,
    "Synthetic Lethality": `https://discodash.discovery-bioinformatics.aws-exelixis.com/synthetic-lethality-plot?gene=${symbol}`,
    "Prevalence Plot": `https://discodash.discovery-bioinformatics.aws-exelixis.com/prevalence-vs-tissue-type-plot?gene=${symbol}`,
  };

  return (
    <MDBox style={{ marginBottom: 40 }} id={`${symbol || "Gene"}-summary`}>
      <MDTypography variant="h3" fontWeight="regular" color="text" mr={3}>
        {symbol || "Gene"} Summary
      </MDTypography>
      <Card>
        <MDBox sx={{ p: 2 }} minHeight={200}>
          {symbol && (
            <>
              <MDTypography fontWeight="regular" variant="h3" fontStyle="bold" color="text" mr={3}>
                {name.substring(0, 1).toLocaleUpperCase() + name.substring(1)}
              </MDTypography>
              {geneAliases.length > 0 && (
                <>
                  <MDTypography fontWeight="light" variant="button" fontStyle="italic" color="text">
                    Alias{geneAliases.length > 1 ? "es" : ""}: {geneAliases.join(" | ")}
                  </MDTypography>
                  <br />
                </>
              )}
              <MDTypography
                variant="button"
                fontWeight="regular"
                color="text"
                fontStyle={summary ? "normal" : "italic"}
                mr={3}
              >
                {summary || "No summary avaliable"}
              </MDTypography>
              <MDBox display="flex" alignItems="center" mt={3}>
                <MDTypography variant="h5" fontWeight="regular" color="text">
                  Links:
                </MDTypography>
                {Object.keys(studyLinks).map((link) => (
                  <MDButton
                    color="info"
                    variant="outlined"
                    size="small"
                    style={{ marginLeft: 10 }}
                    key={link}
                    href={studyLinks[link]}
                    target="_blank"
                  >
                    {link}
                  </MDButton>
                ))}
              </MDBox>
              <MDBox display="flex" alignItems="center" mt={3}>
                <MDBox component="img" src={logo} alt="Brand" width="1rem" mr={1} />
                <MDTypography variant="h5" fontWeight="regular" color="text">
                  DiscoDash:
                </MDTypography>
                {Object.keys(discoDashLinks).map((link) => (
                  <MDButton
                    color="info"
                    variant="outlined"
                    size="small"
                    style={{ marginLeft: 10 }}
                    key={link}
                    href={discoDashLinks[link]}
                    target="_blank"
                  >
                    {link}
                  </MDButton>
                ))}
              </MDBox>
            </>
          )}
        </MDBox>
      </Card>
    </MDBox>
  );
}
GeneSummary.propTypes = {
  geneID: PropTypes.string,
  name: PropTypes.string,
  symbol: PropTypes.string,
  secondarySymbol: PropTypes.string,
  geneAliases: PropTypes.arrayOf(PropTypes.string),
};
GeneSummary.defaultProps = {
  geneID: "-1",
  name: "",
  symbol: "",
  secondarySymbol: "",
  geneAliases: [],
};

export default GeneSummary;

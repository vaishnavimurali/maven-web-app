/* eslint-disable no-unused-vars */
import React, { useState, useEffect, useRef } from "react";
import PropTypes from "prop-types";
import { Document, Page, pdfjs } from "react-pdf/dist/esm/entry.webpack5";
import pdfjsWorker from "pdfjs-dist/build/pdf.worker.entry";

import "react-pdf/dist/esm/Page/AnnotationLayer.css";
import "react-pdf/dist/esm/Page/TextLayer.css";

import Box from "@mui/material/Box";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";

import loadingGif from "assets/images/loading.gif";
import errorImage from "assets/images/error.png";

import MDTypography from "components/MDTypography";
import { Stack, border } from "@mui/system";
import { SurvivalPlotsSSE } from "apiWrapper";

pdfjs.GlobalWorkerOptions.workerSrc = pdfjsWorker;

const singleChartStyle = {
  aspectRatio: "1",
  objectFit: "scale-down",
  maxHeight: "90vh",
  maxWidth: "90vw",
  pointerEvents: "auto",
  bgcolor: "background.paper",
  margin: "auto",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  p: 0.5,
  my: 4,
};

const allChartStyle = {
  aspectRatio: "3/2",
  objectFit: "scale-down",
  maxHeight: "90vh",
  maxWidth: "90vw",
  pointerEvents: "auto",
  bgcolor: "background.paper",
  margin: "auto",
};

const allChartContainerStyle = {
  height: "50%",
  aspectRatio: "1",
  float: "left",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  p: 0.5,
};

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <Box
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      // eslint-disable-next-line react/jsx-props-no-spreading
      {...other}
    >
      {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
    </Box>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node.isRequired,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    "aria-controls": `simple-tabpanel-${index}`,
    key: `simple-tab-${index}`,
  };
}

function displayLoading(height) {
  return <img src={loadingGif} alt="Chart Loading..." height={height} />;
}

function Chart(props) {
  const { chartData, name } = props;

  const elRef = useRef();
  const [height, setHeight] = useState(0);

  useEffect(() => {
    if (!elRef?.current?.parentElement?.clientHeight) {
      return;
    }
    setHeight(elRef.current.parentElement.clientHeight * 0.8);
  }, [elRef?.current?.parentElement?.clientHeight]);

  return (
    <a href={chartData} download target="_blank" rel="noreferrer" ref={elRef}>
      <Document
        file={chartData}
        error={() => displayLoading(height)}
        onSourceError={() => displayLoading(height)}
        noData={() => displayLoading(height)}
        onLoadError={(error) =>
          console.warn(`Error while loading document ${name}! ${error.message}`)
        }
        loading={() => displayLoading(height)}
      >
        <Page pageNumber={1} height={height} />
      </Document>
    </a>
  );
}
Chart.propTypes = {
  // eslint-disable-next-line react/require-default-props
  chartData: PropTypes.string,
  name: PropTypes.string.isRequired,
};

function SurvivalPlotting(props) {
  const { rowID, chartNames } = props;

  const [charts, setCharts] = useState(Array(chartNames.length).fill(null));
  const [errorState, setErrorState] = useState(false);
  const [tValue, setTValue] = useState(0);

  useEffect(() => {
    const eventSource = SurvivalPlotsSSE(rowID);
    eventSource.onmessage = (e) => {
      const message = JSON.parse(e.data);
      if (message.status === "sent") {
        const newCharts = chartNames.map(
          (name) => `data:application/pdf;base64,${message.payload[name]}`
        );
        setCharts(newCharts);
        eventSource.close();
      } else if (message.status === "error") {
        console.error("Something went wrong while loading plots", message);
        setErrorState(true);
        eventSource.close();
      }
    };

    return () => {
      eventSource.close();
    };
  }, []);

  const handleChange = (event, newValue) => {
    setTValue(newValue);
  };

  if (errorState) {
    return (
      <Box sx={singleChartStyle}>
        <Stack spacing={4}>
          <MDTypography variant="h3" fontWeight="regular" align="center" color="text" mr={3}>
            something went wrong
          </MDTypography>
          <img src={errorImage} alt="Error loading charts..." />
        </Stack>
      </Box>
    );
  }

  return chartNames.length === 1 ? (
    <Box sx={singleChartStyle} id="survival-plotting">
      <Chart chartData={charts[0]} height={576} name={chartNames[0]} id={chartNames[0]} />
    </Box>
  ) : (
    <Box display="flex" flexDirection="column" sx={{ height: "100%" }} id="survival-plotting">
      <Box sx={{ borderBottom: 1, borderColor: "divider", pointerEvents: "auto" }}>
        <Tabs value={tValue} onChange={handleChange} aria-label="basic tabs example">
          <Tab label="All Plots" {...a11yProps(0)} />
          {chartNames.map((chartName, index) => (
            <Tab key={chartName} label={chartName} {...a11yProps(index + 1)} />
          ))}
        </Tabs>
      </Box>
      <TabPanel value={tValue} sx={{ height: "100%" }} index={0}>
        <Box sx={allChartStyle}>
          {charts.map((chart, index) => (
            <Box key={`chart_${chartNames[index]}`} sx={allChartContainerStyle}>
              <Chart chartData={chart} name={chartNames[index]} id={chartNames[index]} />
            </Box>
          ))}
        </Box>
      </TabPanel>
      {charts.map((chart, index) => (
        <TabPanel key={`chart_${chartNames[index]}`} value={tValue} index={index + 1}>
          <Box sx={singleChartStyle}>
            <Chart chartData={chart} height={576} name={chartNames[index]} id={chartNames[index]} />
          </Box>
        </TabPanel>
      ))}
    </Box>
  );
}
SurvivalPlotting.propTypes = {
  rowID: PropTypes.string.isRequired,
  chartNames: PropTypes.arrayOf(PropTypes.string).isRequired,
};

export default SurvivalPlotting;

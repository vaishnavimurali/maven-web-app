import React, { useEffect, useState } from "react";
import PropTypes from "prop-types";

import MDBox from "components/MDBox";
import MDButton from "components/MDButton";
import MDTypography from "components/MDTypography";
import { Download } from "@mui/icons-material";

import { Button, Card, Icon, IconButton, Tooltip, Menu, MenuItem, Switch } from "@mui/material";
import {
  DataGridPro,
  GridFilterInputMultipleSingleSelect,
  GridFooter,
  GridFooterContainer,
  GridToolbarContainer,
  GridToolbarFilterButton,
  getGridNumericOperators,
  getGridStringOperators,
  gridSortedRowIdsSelector,
  gridVisibleSortedRowIdsSelector,
  useGridApiContext,
} from "@mui/x-data-grid-pro";
import { styled } from "@mui/material/styles";
import { useSearchParams } from "react-router-dom";
import { GetGeneFromSymbol } from "apiWrapper";
import colorsLight from "assets/theme/base/colors";
import colorsDark from "assets/theme-dark/base/colors";

import { useMaterialUIController } from "context";

const numericValueComparator = (v1, v2) => {
  if (Number.isNaN(v1)) return -1;
  if (Number.isNaN(v2)) return 1;
  return v1 - v2;
};

const StyledDataGrid = styled(DataGridPro)(({ theme }) => ({
  color: theme.palette.text.main,
  border: 0,
  "& .MuiDataGrid-columnsContainer": {
    backgroundColor: "#1d1d1d",
  },
  "& .MuiDataGrid-cell": {
    color: "rgba(0,0,0,.85)",
    borderColor: theme.palette.light.main,
  },
  "& .MuiDataGrid-sortIcon": {
    color: theme.palette.text.main,
  },
  "& .MuiDataGrid-filterIcon": {
    color: theme.palette.text.main,
  },
  "& .MuiDataGrid-menuIconButton": {
    color: theme.palette.text.main,
  },
  "& .MuiDataGrid-menu": {
    width: "100%",
  },
}));

function CustomFooter() {
  return (
    <GridFooterContainer>
      <Tooltip
        title="Multi-sort is enabled on the below tables. Please use shift to add additional sort
        columns."
      >
        <IconButton size="large" color="text" disableRipple disableTouchRipple>
          <Icon baseClassName="material-icons-outlined">help</Icon>
        </IconButton>
      </Tooltip>
      <GridFooter
        sx={{
          border: "none", // To delete double border.
        }}
      />
    </GridFooterContainer>
  );
}

const getUnfilteredRows = ({ apiRef }) => gridSortedRowIdsSelector(apiRef);

const getFilteredRows = ({ apiRef }) => gridVisibleSortedRowIdsSelector(apiRef);

function CustomToolbar(props) {
  const { tableHeader, tableKey, primaryGeneName, secondaryGeneName, addToggle } = props;
  const apiRef = useGridApiContext();
  const [anchorEl, setAnchorEl] = useState(null);
  // eslint-disable-next-line no-unused-vars
  const [toggleOn, setToggleOn] = useState(false);
  const open = Boolean(anchorEl);
  const handleMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleExport = (options) => apiRef.current.exportDataAsCsv(options);

  const handleFilterToggle = () => {
    if (toggleOn) {
      apiRef.current.state.filter.filterModel.items.forEach((item) => {
        if (
          item.columnField === "type" &&
          item.value.length === 1 &&
          item.value.includes("surv.exp.all")
        ) {
          apiRef.current.deleteFilterItem(item);
        }
      });
    } else {
      apiRef.current.upsertFilterItem({
        columnField: "type",
        operatorValue: "isAnyOf",
        value: ["surv.exp.all"],
      });
    }
  };

  useEffect(() => {
    const filterModel = apiRef.current.state.filter.filterModel;

    const usingSurvExpAll = filterModel.items.reduce(
      (acc, cur) =>
        acc ||
        (cur.columnField === "type" &&
          cur.value.length === 1 &&
          cur.value.includes("surv.exp.all")),
      false
    );
    setToggleOn(usingSurvExpAll);
  }, [apiRef.current.state.filter.filterModel]);

  const exportFields = ["gene_e", "gene_m", "indication", "type", "p", "stat", "n", "n_mut"];

  const buttonBaseProps = {
    color: "primary",
    size: "large",
    sx: {
      padding: 0.75,
      pr: 2,
    },
  };

  const fileName = `survivals_${tableKey}${primaryGeneName ? `_${primaryGeneName}` : ""}${
    secondaryGeneName ? `_${secondaryGeneName}` : ""
  }`;

  return (
    <GridToolbarContainer>
      <MDTypography variant="h4" sx={{ p: 1 }}>
        {tableHeader}
      </MDTypography>
      <Button
        {...buttonBaseProps}
        sx={{ ...buttonBaseProps.sx, marginLeft: "auto" }}
        startIcon={<Download />}
        onClick={handleMenuOpen}
      >
        Export CSV
      </Button>
      <Menu
        id={`export-menu-${tableKey}`}
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        MenuListProps={{
          "aria-labelledby": `export-menu-${tableKey}`,
        }}
      >
        <MenuItem
          onClick={() =>
            handleExport({ getRowsToExport: getFilteredRows, fileName, fields: exportFields })
          }
        >
          Filtered Rows
        </MenuItem>
        <MenuItem
          onClick={() =>
            handleExport({ getRowsToExport: getUnfilteredRows, fileName, fields: exportFields })
          }
        >
          Unfiltered Rows
        </MenuItem>
      </Menu>
      <GridToolbarFilterButton
        componentsProps={{
          button: buttonBaseProps,
        }}
      />
      {addToggle && (
        <Button {...buttonBaseProps} onClick={handleFilterToggle}>
          ONLY SURV.EXP.ALL
          <Switch disableRipple checked={toggleOn} onChange={() => {}} name="Only surv.exp.all" />
        </Button>
      )}
    </GridToolbarContainer>
  );
}
CustomToolbar.propTypes = {
  tableHeader: PropTypes.string.isRequired,
  tableKey: PropTypes.string.isRequired,
  primaryGeneName: PropTypes.string.isRequired,
  secondaryGeneName: PropTypes.string.isRequired,
  addToggle: PropTypes.bool.isRequired,
};

function SurvivalTable(props) {
  const {
    rows,
    tableHeader,
    handleChartsOpen,
    tableKey,
    primaryGeneName,
    secondaryGeneName,
    setPrimaryGene,
    setSecondaryGene,
    addToggle,
  } = props;
  const [searchParams, setSearchParams] = useSearchParams();
  // const [filterModel, setFilterModel] = useState({ items: [] });
  //   () => JSON.parse(searchParams.get(`${tableKey}_filter_model`)) || []
  // );
  const [sortModel, setSortModel] = useState(
    () => JSON.parse(searchParams.get(`${tableKey}_sort_model`)) || []
  );
  const [anchorEl, setAnchorEl] = useState(null);

  const [controller] = useMaterialUIController();
  const { darkMode } = controller;
  const colors = darkMode ? colorsDark : colorsLight;

  const showCharts = (cellProps) => {
    const { row } = cellProps;
    if (row.type === "exp.mut")
      return (
        <MDTypography color="text" variant="p" fontWeight="light" fontStyle="italic">
          N/A
        </MDTypography>
      );
    return (
      <MDButton color={darkMode ? "dark" : "light"} onClick={() => handleChartsOpen(row)}>
        Show Plots
      </MDButton>
    );
  };

  const generateEnglish = (cellProps) => {
    const { row } = cellProps;

    const open = anchorEl;

    const handlePopoverOpen = (event) => {
      setAnchorEl(event.currentTarget);
    };

    const handlePopoverClose = () => {
      setAnchorEl(null);
    };
    let english = "No summary";
    switch (row.type) {
      case "surv.exp.all":
        english = `Overall survival is significantly associated with expression levels of gene ${
          row.gene_e
        } (p=${Number(row.p).toPrecision(2)}) in ${row.indication}.`;
        break;
      case "surv.exp":
        english = `Overall survival is significantly associated with expression levels of gene ${
          row.gene_e
        } (p=${Number(row.p).toPrecision(2)}) in ${
          row.indication
        }. (Limited To samples with mutation data)`;
        break;
      case "surv.mut":
        english = `Overall survival is significantly associated with the mutation status of gene ${
          row.gene_e
        } (p=${Number(row.p).toPrecision(2)}) in ${row.indication}.`;
        break;
      case "exp.mut":
        english = `Expression levels of gene ${
          row.gene_e
        } are significantly associated with the mutation status of gene ${row.gene_m} (p=${Number(
          row.p
        ).toPrecision(2)}) in ${row.indication}`;
        break;
      case "surv.exp.mut":
        english = `Overall survival association with expression of gene ${
          row.gene_e
        } is significantly affected by the mutation status of gene ${row.gene_m}(p=${Number(
          row.p
        ).toPrecision(2)}) in ${row.indication}.`;
        break;
      default:
    }
    return (
      <Tooltip title={english} key={`tooltip-${row.id}`}>
        <MDTypography
          variant="text"
          fontWeight="regular"
          color="warning"
          aria-owns={open ? `mouse-over-popover${row.id}` : undefined}
          aria-haspopup="true"
          onMouseEnter={handlePopoverOpen}
          onMouseLeave={handlePopoverClose}
          style={{ cursor: "pointer" }}
        >
          {`${english.substring(0, 16)}...`}
          <span style={{ display: "none" }}>{row.id}</span>
        </MDTypography>
      </Tooltip>
    );
  };

  const clickableGenes = (cellProps) => {
    const { value } = cellProps;
    if (value === "NA") {
      return (
        <MDTypography color="text" variant="p" fontWeight="light" fontStyle="italic">
          N/A
        </MDTypography>
      );
    }
    return (
      <MDTypography
        variant="button"
        fontWeight="regular"
        color="text"
        onClick={() => {
          GetGeneFromSymbol(value).then((gene) => {
            setSecondaryGene(null);
            setPrimaryGene(gene);
          });
        }}
        onContextMenu={(e) => {
          e.preventDefault(); // prevent the default behaviour when right clicked
          GetGeneFromSymbol(value).then((gene) => setSecondaryGene(gene));
        }}
        style={{ cursor: "pointer" }}
      >
        {value}
      </MDTypography>
    );
  };

  const clickableIndication = (cellProps) => {
    const { value } = cellProps;
    return (
      <MDTypography
        variant="button"
        fontWeight="regular"
        color="text"
        onClick={() => {
          searchParams.set("indication", value);
          setSearchParams(searchParams);
        }}
        style={{ cursor: "pointer" }}
      >
        {value}
      </MDTypography>
    );
  };

  const columns = [
    {
      field: "explanation",
      headerName: "Explantion",
      flex: 1,
      width: 140,
      headerAlign: "center",
      renderCell: generateEnglish,
      filterable: false,
    },
    {
      field: "charting",
      headerName: "Charting",
      flex: 1,
      width: 140,
      headerAlign: "center",
      renderCell: showCharts,
      filterable: false,
    },
    {
      field: "gene_e",
      headerName: "Gene E",
      type: "text",
      flex: 1,
      width: 150,
      headerAlign: "center",
      renderCell: clickableGenes,
      filterOperators: getGridStringOperators().filter(
        (operator) => operator.value !== "isEmpty" && operator.value !== "isNotEmpty"
      ),
    },
    {
      field: "gene_m",
      headerName: "Gene M",
      type: "text",
      flex: 1,
      width: 100,
      headerAlign: "center",
      renderCell: clickableGenes,
      filterOperators: getGridStringOperators().filter(
        (operator) => operator.value !== "isEmpty" && operator.value !== "isNotEmpty"
      ),
    },
    {
      field: "indication",
      headerName: "Indication",
      type: "singleSelect",
      valueOptions: [
        "BRCA",
        "CESC",
        "COAD",
        "DBLC",
        "GBM",
        "HNSC",
        "KIRC",
        "KIRP",
        "LGG",
        "LIHC",
        "LUAD",
        "LUSC",
        "OV",
        "PRAD",
        "READ",
        "SARC",
        "SKCM",
      ],
      flex: 1,
      width: 125,
      headerAlign: "center",
      renderCell: clickableIndication,
      filterOperators: (() => {
        const operator = getGridStringOperators().filter((o) => o.value === "isAnyOf")[0];
        operator.InputComponent = GridFilterInputMultipleSingleSelect;
        return [operator];
      })(),
    },
    {
      field: "type",
      headerName: "Type",
      type: "singleSelect",
      valueOptions: ["surv.exp.all", "surv.exp", "surv.mut", "exp.mut", "surv.exp.mut"],
      flex: 1,
      width: 150,
      headerAlign: "center",
      renderCell: (cellProps) => (
        <MDTypography color="text" variant="p" fontWeight="regular">
          {cellProps.value}
        </MDTypography>
      ),
      filterOperators: (() => {
        const operator = getGridStringOperators().filter((o) => o.value === "isAnyOf")[0];
        operator.InputComponent = GridFilterInputMultipleSingleSelect;
        return [operator];
      })(),
    },
    {
      field: "p",
      headerName: "P-Value",
      flex: 1,
      width: 75,
      headerAlign: "center",
      type: "number",
      valueGetter: ({ value }) => value,
      sortComparator: numericValueComparator,
      renderCell: (cellProps) => (
        <Tooltip title={cellProps.value}>
          <MDTypography color="text" variant="p" fontWeight="regular">
            {cellProps.value && Number(cellProps.value).toPrecision(2)}
          </MDTypography>
        </Tooltip>
      ),
      filterOperators: getGridNumericOperators().filter(
        (operator) => operator.value !== "isEmpty" && operator.value !== "isNotEmpty"
      ),
    },
    {
      field: "stat",
      headerName: "Stat",
      flex: 1,
      width: 75,
      headerAlign: "center",
      type: "number",
      valueGetter: ({ value }) => value,
      sortComparator: numericValueComparator,
      renderCell: (cellProps) => (
        <Tooltip title={cellProps.value}>
          <MDTypography color="text" variant="p" fontWeight="regular">
            {cellProps.value && Number(cellProps.value).toPrecision(2)}
          </MDTypography>
        </Tooltip>
      ),
      filterOperators: getGridNumericOperators().filter(
        (operator) => operator.value !== "isEmpty" && operator.value !== "isNotEmpty"
      ),
    },
    {
      field: "n",
      headerName: "N",
      flex: 1,
      width: 75,
      headerAlign: "center",
      type: "number",
      valueGetter: ({ value }) => value && Number(value),
      sortComparator: numericValueComparator,
      renderCell: (cellProps) => (
        <MDTypography color="text" variant="p" fontWeight="regular">
          {cellProps.value && Number(cellProps.value)}
        </MDTypography>
      ),
      filterOperators: getGridNumericOperators().filter(
        (operator) => operator.value !== "isEmpty" && operator.value !== "isNotEmpty"
      ),
    },
    {
      field: "n_mut",
      headerName: "N Mut",
      flex: 1,
      width: 75,
      headerAlign: "center",
      type: "number",
      valueGetter: ({ value }) => value && Number(value),
      sortComparator: numericValueComparator,
      renderCell: (cellProps) =>
        cellProps.value && !Number.isNaN(cellProps.value) ? (
          <MDTypography color="text" variant="p" fontWeight="regular">
            {Number(cellProps.value).toString()}
          </MDTypography>
        ) : (
          <MDTypography color="text" variant="p" fontWeight="light" fontStyle="italic">
            N/A
          </MDTypography>
        ),
      filterOperators: getGridNumericOperators().filter(
        (operator) => operator.value !== "isEmpty" && operator.value !== "isNotEmpty"
      ),
    },
  ];

  const updateSortModel = (newSortModel) => {
    if (newSortModel.length === 0) {
      searchParams.delete(`${tableKey}_sort_model`);
    } else {
      searchParams.set(`${tableKey}_sort_model`, JSON.stringify(newSortModel));
    }
    setSearchParams(searchParams);
    setSortModel(newSortModel);
  };

  const updateFilterModel = (newFilterModel) => {
    const prunedFilterModel = {
      items: newFilterModel.items.filter((item) => item.value),
    };

    if (prunedFilterModel.items.length === 0) {
      searchParams.delete(`${tableKey}_filter_model`);
    } else {
      searchParams.set(`${tableKey}_filter_model`, JSON.stringify(newFilterModel));
    }
    setSearchParams(searchParams);
  };

  return (
    <Card>
      <MDBox style={{ height: 709 }} id={tableKey}>
        <StyledDataGrid
          sortModel={sortModel}
          // filterMode={filterModel}
          onSortModelChange={(newSortModel) => updateSortModel(newSortModel)}
          onFilterModelChange={(newFilterModel) => updateFilterModel(newFilterModel)}
          rows={rows}
          columns={columns}
          checkboxSelection
          disableDensitySelector
          disableColumnSelector
          rowHeight={60}
          pageSize={10}
          rowsPerPageOptions={[10]}
          initialState={{
            filter: {
              filterModel: JSON.parse(searchParams.get(`${tableKey}_filter_model`)) || {
                items: [],
              },
            },
          }}
          componentsProps={{
            panel: {
              placement: "bottom-end",
            },
            basePopper: {
              sx: {
                "&.MuiDataGrid-menu .MuiPaper-root": { backgroundColor: colors.background.card },
              },
            },
            filterPanel: {
              sx: {
                // Customize inputs using css selectors
                "& .MuiDataGrid-filterForm": { p: 2 },
                "& .MuiDataGrid-filterFormLogicOperatorInput": { mr: 2 },
                "& .MuiDataGrid-filterFormColumnInput": { mr: 2, width: 150 },
                "& .MuiDataGrid-filterFormOperatorInput": { mr: 2 },
                "& .MuiDataGrid-filterFormValueInput": { width: 300 },
                backgroundColor: colors.background.popup,
              },
              filterFormProps: {
                // Customize inputs by passing props
                linkOperatorInputProps: {
                  variant: "outlined",
                  size: "large",
                  sx: { mt: "auto", pr: ".6rem" },
                },
                columnInputProps: {
                  variant: "outlined",
                  size: "large",
                  sx: { mt: "auto" },
                },
                operatorInputProps: {
                  variant: "outlined",
                  size: "large",
                  sx: { mt: "auto" },
                },
                valueInputProps: {
                  InputComponentProps: {
                    variant: "outlined",
                    size: "large",
                  },
                  sx: {
                    "& .MuiAutocomplete-input": {
                      height: ".7rem",
                    },
                  },
                },
                deleteIconProps: {
                  sx: {
                    "& .MuiSvgIcon-root": { color: colors.text.main },
                  },
                },
              },
            },
            toolbar: {
              tableHeader,
              tableKey,
              primaryGeneName,
              secondaryGeneName,
              addToggle,
            },
          }}
          components={{
            Footer: CustomFooter,
            Toolbar: CustomToolbar,
          }}
        />
      </MDBox>
    </Card>
  );
}
SurvivalTable.propTypes = {
  handleChartsOpen: PropTypes.func.isRequired,
  rows: PropTypes.arrayOf(PropTypes.object).isRequired,
  tableHeader: PropTypes.string.isRequired,
  tableKey: PropTypes.string.isRequired,
  primaryGeneName: PropTypes.string.isRequired,
  secondaryGeneName: PropTypes.string.isRequired,
  setPrimaryGene: PropTypes.func.isRequired,
  setSecondaryGene: PropTypes.func.isRequired,
  addToggle: PropTypes.bool,
};
SurvivalTable.defaultProps = {
  addToggle: false,
};

function SearchResults(props) {
  const { rows, handleChartsOpen, primaryGene, secondaryGene, setPrimaryGene, setSecondaryGene } =
    props;

  const primaryName = primaryGene ? primaryGene.symbol : "";
  const secondaryName = secondaryGene ? secondaryGene.symbol : "";

  return (
    <MDBox style={{ marginBottom: 40 }} id="survival-search-results">
      <MDTypography variant="h3" fontWeight="regular" color="text" mb={1} mr={1}>
        Expression and Mutation Effects on Survival with {primaryName || "Gene"}
      </MDTypography>
      <SurvivalTable
        handleChartsOpen={handleChartsOpen}
        rows={rows[0]}
        tableHeader={`${primaryName || "Gene"} as Expressed Gene${
          secondaryName && ` (${secondaryName} as Mutated)`
        }`}
        tableKey="table_e"
        primaryGeneName={primaryName}
        secondaryGeneName={secondaryName}
        addToggle
        setPrimaryGene={setPrimaryGene}
        setSecondaryGene={setSecondaryGene}
      />
      <br />
      <SurvivalTable
        handleChartsOpen={handleChartsOpen}
        rows={rows[1]}
        tableHeader={`${primaryName || "Gene"} as Mutated Gene${
          secondaryName && ` (${secondaryName} as Expressed)`
        }`}
        tableKey="table_m"
        primaryGeneName={primaryName}
        secondaryGeneName={secondaryName}
        setPrimaryGene={setPrimaryGene}
        setSecondaryGene={setSecondaryGene}
      />
    </MDBox>
  );
}
SearchResults.propTypes = {
  rows: PropTypes.arrayOf(PropTypes.array).isRequired,
  handleChartsOpen: PropTypes.func.isRequired,

  setPrimaryGene: PropTypes.func.isRequired,
  primaryGene: PropTypes.shape({
    symbol: PropTypes.string,
    hgnc_id: PropTypes.string,
    name: PropTypes.string,
  }),

  setSecondaryGene: PropTypes.func.isRequired,
  secondaryGene: PropTypes.shape({
    symbol: PropTypes.string,
    hgnc_id: PropTypes.string,
    name: PropTypes.string,
  }),
};
SearchResults.defaultProps = {
  primaryGene: {},
  secondaryGene: {},
};

export default SearchResults;

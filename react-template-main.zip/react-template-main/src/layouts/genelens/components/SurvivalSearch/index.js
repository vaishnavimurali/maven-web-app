import React, { useState, useEffect, useRef } from "react";
import { useSearchParams } from "react-router-dom";
import PropTypes from "prop-types";

import MDBox from "components/MDBox";
import MDButton from "components/MDButton";
import MDTypography from "components/MDTypography";

import { Oval } from "react-loading-icons";

import GeneSelector from "components/custom/GeneSelector";
import IndicationSelector from "components/custom/IndicationSelector";
import { GetSurvivals } from "apiWrapper";

import colors from "assets/theme/base/colors";

function GeneSearch(props) {
  const {
    setRows,
    primaryGene,
    setPrimaryGene,
    secondaryGene,
    setSecondaryGene,
    indication,
    setIndication,
  } = props;

  const [searchParams, setSearchParams] = useSearchParams();
  const [searching, setSearching] = useState(false);

  const currentSearch = useRef({
    primaryGene,
    secondaryGene,
    indication,
  });

  const searchNow = () => {
    currentSearch.current = {
      primaryGene,
      secondaryGene,
      indication,
    };

    // Set Search Params
    if (!primaryGene) {
      searchParams.delete("gene_1");
    } else {
      searchParams.set("gene_1", primaryGene.symbol);
    }
    if (!secondaryGene) {
      searchParams.delete("gene_2");
    } else {
      searchParams.set("gene_2", secondaryGene.symbol);
    }
    if (!indication) {
      searchParams.delete("indication");
    } else {
      searchParams.set("indication", indication);
    }

    setSearchParams(searchParams);

    setRows([[], []]);

    // Check if primary gene exists in search
    if (!primaryGene) {
      setSearching(false);
      return;
    }

    setSearching(true);

    GetSurvivals(primaryGene?.symbol, secondaryGene?.symbol, indication).then((rows) => {
      setSearching(false);

      // Check for stale closure against current search ref
      if (
        primaryGene?.symbol === currentSearch.current.primaryGene?.symbol &&
        secondaryGene?.symbol === currentSearch.current.secondaryGene?.symbol &&
        indication === currentSearch.current.indication
      )
        setRows(rows);
    });
  };

  useEffect(() => {
    searchNow(primaryGene, secondaryGene, indication);
  }, [primaryGene, secondaryGene, indication]);

  return (
    <MDBox style={{ marginBottom: 30 }} id="survival-search">
      <MDTypography variant="h3" fontWeight="regular" color="text" mr={3} mb={2}>
        Gene Search
      </MDTypography>
      <form>
        <MDBox display="flex">
          <GeneSelector
            label="Primary Gene"
            value={primaryGene}
            setValue={setPrimaryGene}
            _style={{ width: 300 }}
          />
          <GeneSelector
            label="Secondary Gene (optional)"
            value={secondaryGene}
            setValue={setSecondaryGene}
            _style={{ marginLeft: 20, width: 300 }}
          />
          <IndicationSelector
            label="Indication"
            value={indication}
            setValue={setIndication}
            searchNow={searchNow}
            style={{ marginLeft: 20, width: 150 }}
          />
          <MDButton
            color="info"
            onClick={searchNow}
            style={{ marginLeft: 20 }}
            id="survival-search-button"
          >
            Search
          </MDButton>

          {searching && (
            <Oval
              id="survival-search-indicator"
              stroke={colors.exelixis}
              width="50"
              height="50"
              style={{ marginLeft: 10 }}
            />
          )}
        </MDBox>
      </form>
    </MDBox>
  );
}

GeneSearch.propTypes = {
  setRows: PropTypes.func.isRequired,

  setPrimaryGene: PropTypes.func.isRequired,
  primaryGene: PropTypes.shape({
    symbol: PropTypes.string,
    hgnc_id: PropTypes.string,
    name: PropTypes.string,
  }),

  setSecondaryGene: PropTypes.func.isRequired,
  secondaryGene: PropTypes.shape({
    symbol: PropTypes.string,
    hgnc_id: PropTypes.string,
    name: PropTypes.string,
  }),

  setIndication: PropTypes.func.isRequired,
  indication: PropTypes.string,
};
GeneSearch.defaultProps = {
  primaryGene: {},
  secondaryGene: {},
  indication: null,
};

export default GeneSearch;

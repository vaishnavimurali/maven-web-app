/**
=========================================================
* Material Dashboard 2 React - v2.1.0
=========================================================

* Product Page: https://www.creative-tim.com/product/material-dashboard-react
* Copyright 2022 Creative Tim (https://www.creative-tim.com)

Coded by www.creative-tim.com

 =========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
*/

// React
import React, { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";

// Material Dashboard 2 React example components
import DashboardLayout from "components/LayoutContainers/DashboardLayout";
import MDBox from "components/MDBox";
import MDTypography from "components/MDTypography";

// Additional libraries
import { JsonViewer, createDataType } from "@textea/json-viewer";
import { GetReport } from "apiWrapper";

/* eslint-disable react/prop-types */

function Reports() {
  const [searchParams] = useSearchParams();
  const [report, setReport] = useState({
    title: "No report loaded",
    description: "please include the report ID in the URL parameters",
    report: null,
  });

  useEffect(() => {
    const LoadReport = async () => {
      const reportID = searchParams.get("id");
      if (reportID) {
        setReport(await GetReport(reportID));
      }
    };
    LoadReport();
  }, []);

  return (
    <DashboardLayout headerTitle="Reports">
      <MDBox>
        <MDBox p={10} alignItems="center">
          {/* Header */}
          <MDTypography variant="h2" align="center" fontWeight="regular" color="text">
            {report.title}
          </MDTypography>
          <MDTypography variant="h4" align="center" fontWeight="regular" color="text">
            {report.description}
          </MDTypography>
          <JsonViewer
            value={report.report}
            rootName={false}
            defaultInspectDepth={3}
            // just define it
            valueTypes={[
              createDataType(
                (value) => typeof value === "string" && value.startsWith("https://"),
                // eslint-disable-next-line react/no-unstable-nested-components
                (props) => (
                  <a href={props.value} target="_blank" rel="noreferrer">
                    {props.value}
                  </a>
                )
              ),
            ]}
          />
        </MDBox>
      </MDBox>
    </DashboardLayout>
  );
}

export default Reports;

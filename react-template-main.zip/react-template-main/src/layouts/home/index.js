/**
=========================================================
* Material Dashboard 2 React - v2.1.0
=========================================================

* Product Page: https://www.creative-tim.com/product/material-dashboard-react
* Copyright 2022 Creative Tim (https://www.creative-tim.com)

Coded by www.creative-tim.com

 =========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
*/

// Material Dashboard 2 React example components
import React from "react";
import DashboardLayout from "components/LayoutContainers/DashboardLayout";
import MDBox from "components/MDBox";
import MDTypography from "components/MDTypography";
import { Oval } from "react-loading-icons";
import { Player } from "video-react";

import { useMaterialUIController } from "context";

import colors from "assets/theme/base/colors";

import "video-react/dist/video-react.css"; // import css

function Home() {
  const [controller] = useMaterialUIController();
  const { authState, userInfo } = controller;

  if (!authState) {
    return (
      <DashboardLayout headerTitle="Home">
        <Oval
          stroke={colors.exelixis}
          style={{ marginLeft: 10, marginTop: 3, position: "absolute" }}
        />
      </DashboardLayout>
    );
  }

  if (!userInfo || !authState.accessToken || !authState.idToken) {
    return (
      <DashboardLayout headerTitle="Home">
        <MDBox display="flex" justifyContent="center" alignItems="center">
          <MDBox p={10} alignItems="center">
            {/* Header */}
            <MDTypography
              variant="h1"
              align="center"
              fontWeight="regular"
              color="text"
              id="welcome-message"
            >
              Welcome to GeneLens, a product of Scientific Strategy Bioinformatics
            </MDTypography>
            <MDTypography
              variant="h5"
              align="center"
              fontWeight="regular"
              color="text"
              style={{ marginBottom: 20 }}
            >
              Please sign in to continue
            </MDTypography>
          </MDBox>
        </MDBox>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout headerTitle="Home">
      <MDBox display="flex" justifyContent="center" alignItems="center">
        <MDBox p={10} alignItems="center">
          {/* Header */}
          <MDTypography
            variant="h1"
            align="center"
            fontWeight="regular"
            color="text"
            id="welcome-message"
          >
            Welcome to GeneLens{userInfo.given_name ? `, ${userInfo.given_name}` : ""}
          </MDTypography>
          <MDTypography
            variant="h5"
            align="center"
            fontWeight="regular"
            color="text"
            style={{ marginBottom: 20 }}
          >
            If this is your first time here, please watch this brief introductory video.
          </MDTypography>
          <Player>
            <source src="https://dj44as224q6q2.cloudfront.net/GLIntro2RR2.mp4" />
          </Player>
        </MDBox>
      </MDBox>
    </DashboardLayout>
  );
}

export default Home;

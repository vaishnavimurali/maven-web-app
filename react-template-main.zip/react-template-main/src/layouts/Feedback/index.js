// Authentication layout components

import PageLayout from "components/LayoutContainers/PageLayout";
import MDBox from "components/MDBox";

function Test() {
  return (
    <PageLayout>
      <MDBox height="100vh">
        <iframe
          width="100%"
          height="100%"
          src="https://forms.office.com/Pages/ResponsePage.aspx?id=-nWI1CH9j0ax0VpvnCiHaLJU7aKwn2tFmsjk9qj_0dpUMVE2S1NGREE5NkUyQktSMzNMTjdZUVMxSy4u&embed=true"
          style={{ border: "none", maxWidth: "100%", maxHeight: "100vh" }}
          title="test"
        />
      </MDBox>
    </PageLayout>
  );
}

export default Test;

/* eslint-disable */

import {
  GeneSelectorSearch,
  GetGeneFromAlias,
  GetGeneFromExactSearch,
  GetGeneFromName,
  GetGeneFromSymbol,
} from "apiWrapper";

import fetch from "jest-fetch-mock";

fetch.enableMocks();

beforeEach(() => {
  fetch.resetMocks();
});

test("Gets gene from symbol (C10orf126)", () => {
  const search = "C10orf126";

  // simulating a server response
  fetch.mockResponseOnce(
    JSON.stringify({
      data: {
        Hgnccsas: {
          docs: [
            {
              symbol: "C10orf126",
              name: "chromosome 10 open reading frame 126",
              hgnc_id: "HGNC:28693",
              entrez_id: "283080",
              alias_symbol: "MGC45541|bA492M23.1",
              prev_symbol: null,
            },
          ],
        },
      },
    })
  );

  GetGeneFromSymbol(search).then((result) =>
    expect(result).toEqual({
      symbol: "C10orf126",
      name: "chromosome 10 open reading frame 126",
      hgnc_id: "HGNC:28693",
      entrez_id: "283080",
      alias_symbol: "MGC45541|bA492M23.1",
      prev_symbol: null,
    })
  );
});

test("Gets gene from symbol (invalid symbol)", async () => {
  const search = "L-SOX5";
  fetch.mockResponseOnce(
    JSON.stringify({
      data: {
        Hgnccsas: {
          docs: [],
        },
      },
    })
  );

  GetGeneFromSymbol(search).then((result) => expect(result).toBe(null));
});

test("Gets gene from alias (GARS-AIRS-GART)", async () => {
  const search = "GARS-AIRS-GART";
  fetch.mockResponseOnce(
    JSON.stringify({
      data: {
        Hgnccsas: {
          docs: [
            {
              symbol: "GART",
              name: "phosphoribosylglycinamide formyltransferase, phosphoribosylglycinamide synthetase, phosphoribosylaminoimidazole synthetase",
              hgnc_id: "HGNC:4163",
              entrez_id: "2618",
              alias_symbol: "GARS-AIRS-GART",
              prev_symbol: "PRGS|PGFT",
            },
          ],
        },
      },
    })
  );

  GetGeneFromAlias(search).then((result) =>
    expect(result).toEqual({
      symbol: "GART",
      name: "phosphoribosylglycinamide formyltransferase, phosphoribosylglycinamide synthetase, phosphoribosylaminoimidazole synthetase",
      hgnc_id: "HGNC:4163",
      entrez_id: "2618",
      alias_symbol: "GARS-AIRS-GART",
      prev_symbol: "PRGS|PGFT",
    })
  );
});

test("Gets gene from alias (invalid alias)", async () => {
  const search = "JPEF";
  fetch.mockResponseOnce(
    JSON.stringify({
      data: {
        Hgnccsas: {
          docs: [],
        },
      },
    })
  );
  GetGeneFromAlias(search).then((result) => expect(result).toBe(null));
});

test("Gets gene from name (Androgen receptor)", async () => {
  const search = "Androgen receptor";
  fetch.mockResponseOnce(
    JSON.stringify({
      data: {
        Hgnccsas: {
          docs: [
            {
              symbol: "NXTAR",
              name: "negative expression of androgen receptor regulating lncRNA",
              hgnc_id: "HGNC:56212",
              entrez_id: "105373241",
              alias_symbol: null,
              prev_symbol: null,
            },
            {
              symbol: "AR",
              name: "androgen receptor",
              hgnc_id: "HGNC:644",
              entrez_id: "367",
              alias_symbol: "AIS|NR3C4|SMAX1|HUMARA",
              prev_symbol: "DHTR|SBMA",
            },
            {
              symbol: "ARLNC1",
              name: "androgen receptor regulated long noncoding RNA 1",
              hgnc_id: "HGNC:53032",
              entrez_id: "100996425",
              alias_symbol: "PRCAT47",
              prev_symbol: "LINC02170",
            },
            {
              symbol: "ARNILA",
              name: "androgen receptor negatively regulated lncRNA",
              hgnc_id: "HGNC:54484",
              entrez_id: "116435288",
              alias_symbol: null,
              prev_symbol: null,
            },
          ],
        },
      },
    })
  );

  GetGeneFromName(search).then((result) =>
    expect(result).toEqual({
      symbol: "AR",
      name: "androgen receptor",
      hgnc_id: "HGNC:644",
      entrez_id: "367",
      alias_symbol: "AIS|NR3C4|SMAX1|HUMARA",
      prev_symbol: "DHTR|SBMA",
    })
  );
});

test("Gets gene from name (invalid name)", async () => {
  const search = "nonexistant gene";
  fetch.mockResponseOnce(
    JSON.stringify({
      data: {
        Hgnccsas: {
          docs: [],
        },
      },
    })
  );

  GetGeneFromName(search).then((result) => expect(result).toBe(null));
});

test("Gets gene from exact search (HCK)", async () => {
  const search = "HCK";
  fetch.mockResponseOnce(
    JSON.stringify({
      data: {
        Hgnccsas: {
          docs: [
            {
              symbol: "HCK",
              name: "HCK proto-oncogene, Src family tyrosine kinase",
              hgnc_id: "HGNC:4840",
              entrez_id: "3055",
              alias_symbol: "JTK9",
              prev_symbol: null,
            },
          ],
        },
      },
    })
  );

  GetGeneFromExactSearch(search).then((result) =>
    expect(result).toEqual({
      symbol: "HCK",
      name: "HCK proto-oncogene, Src family tyrosine kinase",
      hgnc_id: "HGNC:4840",
      entrez_id: "3055",
      alias_symbol: "JTK9",
      prev_symbol: null,
    })
  );
});

test("Gets gene from exact search (JTK9)", async () => {
  const search = "JTK9";
  fetch
    .once(
      JSON.stringify({
        data: {
          Hgnccsas: {
            docs: [],
          },
        },
      })
    )
    .once(
      JSON.stringify({
        data: {
          Hgnccsas: {
            docs: [
              {
                symbol: "HCK",
                name: "HCK proto-oncogene, Src family tyrosine kinase",
                hgnc_id: "HGNC:4840",
                entrez_id: "3055",
                alias_symbol: "JTK9",
                prev_symbol: null,
              },
            ],
          },
        },
      })
    )
    .once(
      JSON.stringify({
        data: {
          Hgnccsas: {
            docs: [
              {
                symbol: "HCK",
                name: "HCK proto-oncogene, Src family tyrosine kinase",
                hgnc_id: "HGNC:4840",
                entrez_id: "3055",
                alias_symbol: "JTK9",
                prev_symbol: null,
              },
            ],
          },
        },
      })
    );

  GetGeneFromExactSearch(search).then((result) =>
    expect(result).toEqual({
      symbol: "HCK",
      name: "HCK proto-oncogene, Src family tyrosine kinase",
      hgnc_id: "HGNC:4840",
      entrez_id: "3055",
      alias_symbol: "JTK9",
      prev_symbol: null,
    })
  );
});

test("Gets gene from exact search (HCK proto-oncogene, Src family tyrosine kinase)", async () => {
  const search = "HCK proto-oncogene, Src family tyrosine kinase";
  fetch
    .once(
      JSON.stringify({
        data: {
          Hgnccsas: {
            docs: [],
          },
        },
      })
    )
    .once(
      JSON.stringify({
        data: {
          Hgnccsas: {
            docs: [],
          },
        },
      })
    )
    .once(
      JSON.stringify({
        data: {
          Hgnccsas: {
            docs: [
              {
                symbol: "HCK",
                name: "HCK proto-oncogene, Src family tyrosine kinase",
                hgnc_id: "HGNC:4840",
                entrez_id: "3055",
                alias_symbol: "JTK9",
                prev_symbol: null,
              },
            ],
          },
        },
      })
    );

  GetGeneFromExactSearch(search).then((result) =>
    expect(result).toEqual({
      symbol: "HCK",
      name: "HCK proto-oncogene, Src family tyrosine kinase",
      hgnc_id: "HGNC:4840",
      entrez_id: "3055",
      alias_symbol: "JTK9",
      prev_symbol: null,
    })
  );
});

test("Gets gene from name (invalid gene)", async () => {
  const search = "nonsense";

  fetch
    .once(
      JSON.stringify({
        data: {
          Hgnccsas: {
            docs: [],
          },
        },
      })
    )
    .once(
      JSON.stringify({
        data: {
          Hgnccsas: {
            docs: [],
          },
        },
      })
    )
    .once(
      JSON.stringify({
        data: {
          Hgnccsas: {
            docs: [],
          },
        },
      })
    );

  GetGeneFromExactSearch(search).then((result) => expect(result).toBe(null));
});

test("Run gene selector search", async () => {
  const search = "sox5";
  fetch
    .once(
      JSON.stringify({
        data: {
          Hgnccsas: {
            docs: [
              {
                symbol: "SOX5",
                name: "SRY-box transcription factor 5",
                hgnc_id: "HGNC:11201",
                entrez_id: "6660",
                alias_symbol: "L-SOX5|MGC35153",
                prev_symbol: null,
              },
              {
                symbol: "SOX5-AS1",
                name: "SOX5 antisense RNA 1",
                hgnc_id: "HGNC:53311",
                entrez_id: "101928471",
                alias_symbol: null,
                prev_symbol: null,
              },
              {
                symbol: "SOX5P1",
                name: "SOX5 pseudogene 1",
                hgnc_id: "HGNC:11202",
                entrez_id: "6661",
                alias_symbol: "SOX29",
                prev_symbol: "SOX5P",
              },
            ],
          },
        },
      })
    )
    .once(
      JSON.stringify({
        data: {
          Hgnccsas: {
            docs: [
              {
                symbol: "SOX5",
                name: "SRY-box transcription factor 5",
                hgnc_id: "HGNC:11201",
                entrez_id: "6660",
                alias_symbol: "L-SOX5|MGC35153",
                prev_symbol: null,
              },
              {
                symbol: "SOX5P1",
                name: "SOX5 pseudogene 1",
                hgnc_id: "HGNC:11202",
                entrez_id: "6661",
                alias_symbol: "SOX29",
                prev_symbol: "SOX5P",
              },
              {
                symbol: "LINC02566",
                name: "long intergenic non-protein coding RNA 2566",
                hgnc_id: "HGNC:53606",
                entrez_id: "123706510",
                alias_symbol: "LNC-Sox5",
                prev_symbol: null,
              },
            ],
          },
        },
      })
    )
    .once(
      JSON.stringify({
        data: {
          Hgnccsas: {
            docs: [
              {
                symbol: "SOX5-AS1",
                name: "SOX5 antisense RNA 1",
                hgnc_id: "HGNC:53311",
                entrez_id: "101928471",
                alias_symbol: null,
                prev_symbol: null,
              },
              {
                symbol: "SOX5P1",
                name: "SOX5 pseudogene 1",
                hgnc_id: "HGNC:11202",
                entrez_id: "6661",
                alias_symbol: "SOX29",
                prev_symbol: "SOX5P",
              },
            ],
          },
        },
      })
    );
  GeneSelectorSearch(search)
    .then((genes) =>
      genes.reduce(
        (acc, gene) => {
          acc.symbols.push(gene.symbol);
          switch (gene.method) {
            case "symbol":
              acc.numBySymbol += 1;
              break;
            case "alias":
              acc.numByAlias += 1;
              break;
            case "name":
              acc.numByName += 1;
              break;
            default:
              break;
          }
          return acc;
        },
        { symbols: [], numBySymbol: 0, numByAlias: 0, numByName: 0 }
      )
    )
    .then((stats) =>
      expect(stats).toEqual({
        symbols: [
          "SOX5",
          "SOX5-AS1",
          "SOX5P1",
          "SOX5P1",
          "SOX5",
          "LINC02566",
          "SOX5-AS1",
          "SOX5P1",
        ],
        numBySymbol: 3,
        numByAlias: 3,
        numByName: 2,
      })
    );
});

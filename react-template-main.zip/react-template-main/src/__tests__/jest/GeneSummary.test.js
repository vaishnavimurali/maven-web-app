/* eslint-disable */
import { render, waitFor } from "@testing-library/react";
import GeneSummary from "layouts/genelens/components/GeneSummary";
import { LicenseInfo } from "@mui/x-license-pro";

import fetch from "jest-fetch-mock";
import { MaterialUIControllerProvider } from "context";

import MockTheme from "../../assets/theme/MockTheme";

LicenseInfo.setLicenseKey(
  "e3dcf2c27421c89cd076307f6a252fa0Tz00NjUzMixFPTE2ODgxNDg3Mzg4NDQsUz1wcm8sTE09c3Vic2NyaXB0aW9uLEtWPTI="
);

fetch.disableMocks();

jest.mock(
  "../../components/MDBox",
  () =>
    function (props) {
      const { children, alignItems, minHeight, ...otherProps } = props;

      return <div {...otherProps}>{children}</div>;
    }
);
jest.mock(
  "../../components/MDTypography",
  () =>
    function (props) {
      const { children, alignItems, minHeight, ...otherProps } = props;

      return <p {...otherProps}>{children}</p>;
    }
);

jest.mock(
  "../../components/MDButton",
  () =>
    function (props) {
      const { children, alignItems, minHeight, ...otherProps } = props;
      return <button {...otherProps}>{children}</button>;
    }
);

const summary =
  "This gene encodes a member of the SOX (SRY-related HMG-box) family of transcription factors involved in the regulation of embryonic development and in the determination of the cell fate. The encoded protein may act as a transcriptional regulator after forming a protein complex with other proteins. The encoded protein may play a role in chondrogenesis. A pseudogene of this gene is located on chromosome 8. Multiple transcript variants encoding distinct isoforms have been identified for this gene. [provided by RefSeq, Jul 2008]";

it("Renders SOX5 summary", async () => {
  const geneID = "6660";
  const symbol = "SOX5";
  const secondarySymbol = "";
  const geneAliases = ["L-SOX5", "MGC35153"];
  const component = render(
    <MaterialUIControllerProvider>
      <MockTheme>
        <GeneSummary
          geneID={geneID}
          symbol={symbol}
          secondarySymbol={secondarySymbol}
          geneAliases={geneAliases}
        />
      </MockTheme>
    </MaterialUIControllerProvider>
  );

  await waitFor(() =>
    expect(component.queryByText("No summary avaliable")).not.toBeInTheDocument()
  );

  expect(component.getByText(summary)).toBeInTheDocument();
  expect(component.getByText("SOX5 Summary")).toBeInTheDocument();

  expect(component.getAllByRole("button").length).toBe(12);
});

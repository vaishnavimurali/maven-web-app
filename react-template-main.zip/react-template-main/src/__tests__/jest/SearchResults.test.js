/* eslint-disable */
import { render, waitFor } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import SearchResults from "layouts/genelens/components/SearchResults";
import { LicenseInfo } from "@mui/x-license-pro";
import fetch from "jest-fetch-mock";
import { MaterialUIControllerProvider } from "context";
import MockTheme from "../../assets/theme/MockTheme";
import { Tooltip } from "@mui/material";

LicenseInfo.setLicenseKey(
  "e3dcf2c27421c89cd076307f6a252fa0Tz00NjUzMixFPTE2ODgxNDg3Mzg4NDQsUz1wcm8sTE09c3Vic2NyaXB0aW9uLEtWPTI="
);
fetch.disableMocks();

jest.mock(
  "../../components/MDBox",
  () =>
    function (props) {
      const { children, alignItems, minHeight, marginLeft, marginBottom, ...otherProps } = props;

      return <div {...otherProps}>{children}</div>;
    }
);
jest.mock(
  "../../components/MDTypography",
  () =>
    function (props) {
      const { children, alignItems, minHeight, marginLeft, marginBottom, ...otherProps } = props;

      return <p {...otherProps}>{children}</p>;
    }
);

jest.mock(
  "../../components/MDButton",
  () =>
    function (props) {
      const { children, alignItems, minHeight, marginLeft, marginBottom, startIcon, ...otherProps } = props;
      return <button {...otherProps}>{children}</button>;
    }
);

jest.mock(
  "@mui/material",
  () => {
    const lib = jest.requireActual("@mui/material");

    return {
      ...lib,
      Tooltip: ({children}) => (<div>{children}</div>)
    }
  }
)

it("Renders", async () => {
  const rows = [
    [
      {
        gene_e: "SOX5",
        gene_m: "PCDHA3",
        indication: "HNSC",
        type: "surv.exp.mut",
        p: 0,
        stat: 396.66339722681,
        n: 497,
        n_mut: "12",
        id: "6421c78d05bd9f5d4f71e421",
      },
    ],
    [
      {
        gene_e: "PCDHA3",
        gene_m: "SOX5",
        indication: "HNSC",
        type: "exp.mut",
        p: 0.0190475590822955,
        stat: 2.56092723904857,
        n: 497,
        n_mut: "7",
        id: "6421c66c05bd9f5d4f356d56",
      },
    ],
  ];
  const handleChartsOpen = () => {};
  const primaryGene = {
    symbol: "SOX5",
    hgnc_id: "11201",
    name: "SRY-box transcription factor 5",
  };
  const secondaryGene = {
    symbol: "PCDHA3",
    hgnc_id: "8669",
    name: "Protocadherin alpha 3",
  };
  const setPrimaryGene = () => {};
  const setSecondaryGene = () => {};

  const component = render(
    <MemoryRouter>
      <MaterialUIControllerProvider>
        <MockTheme>
          <SearchResults
            rows={rows}
            handleChartsOpen={handleChartsOpen}
            primaryGene={primaryGene}
            secondaryGene={secondaryGene}
            setPrimaryGene={setPrimaryGene}
            setSecondaryGene={setSecondaryGene}
          />
        </MockTheme>
      </MaterialUIControllerProvider>
    </MemoryRouter>
  );
});

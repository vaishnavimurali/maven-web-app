import sys
import argparse
import time
import json
import traceback
import urllib
from datetime import datetime, timedelta

# Include boto3, the Python SDK's main package:
import boto3

from selenium import webdriver
from selenium.webdriver import Remote as RemoteDriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.options import BaseOptions as Options
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.chrome.service import Service as ChromiumService
from selenium.webdriver.chromium.options import ChromiumOptions
from selenium.webdriver.firefox.service import Service as FirefoxService
from selenium.webdriver.firefox.options import Options as FirefoxOptions
from selenium.webdriver.remote.webdriver import WebDriver

from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.core.utils import ChromeType
from webdriver_manager.firefox import GeckoDriverManager

from selenium.common.exceptions import NoSuchElementException

SCROLL_TO = "arguments[0].scrollIntoView({behavior: 'instant', block: 'end'});"
CLICK = "arguments[0].click();"

# in your tests:
# Set up the Device Farm client, get a driver URL:
class DevicefarmTestSuite:
  def setup_method(self, options: Options, arn: str):
    devicefarm_client = boto3.client("devicefarm", region_name="us-west-2")
    testgrid_url_response = devicefarm_client.create_test_grid_url(
      projectArn=arn,
      expiresInSeconds=300)
    self.driver = RemoteDriver(command_executor=testgrid_url_response["url"], options=options)

def main(project_arn: str | None, user_email: str, user_password: str, base_url: str, browser_type: str, webdriver_start_time_filename: str | None, donwload_path: str):
    match browser_type:
        case "chrome":
            if project_arn is None:
                print("No selenium project ARN supplied")
                exit(1)
            testSuite = DevicefarmTestSuite()
            chrome_options = ChromeOptions()
            download_option = {"download.default_directory": donwload_path, "safebrowsing.enabled":"false"}
            chrome_options.add_experimental_option("prefs", download_option)
            chrome_options.add_argument("--disable-gpu")
            chrome_options.add_argument("--disable-extensions")
            chrome_options.add_argument("--window-size=1920,1080")
            testSuite.setup_method(chrome_options, project_arn)
            run_tests(driver=testSuite.driver, base_url=base_url, email=user_email, password=user_password, webdriver_start_time_filename=webdriver_start_time_filename)
        case "firefox":
            if project_arn is None:
                print("No selenium project ARN supplied")
                exit(1)
            testSuite = DevicefarmTestSuite()
            firefox_options = FirefoxOptions()
            firefox_options.set_preference("browser.download.alwaysOpenPanel", False)
            firefox_options.set_preference("browser.download.folderList", 2)
            firefox_options.set_preference("browser.download.manager.showWhenStarting", False)
            firefox_options.set_preference("browser.download.dir", donwload_path)
            firefox_options.set_preference("browser.helperApps.neverAsk.saveToDisk", "application/x-gzip")
            firefox_options.add_argument('--width=1920')
            firefox_options.add_argument('--height=1080')
            testSuite.setup_method(firefox_options, project_arn)
            run_tests(driver=testSuite.driver, base_url=base_url, email=user_email, password=user_password, webdriver_start_time_filename=webdriver_start_time_filename)
        case "internal":
            chrome_options = ChromeOptions()
            download_option = {"download.default_directory": donwload_path, "safebrowsing.enabled":"false"}
            chrome_options.add_experimental_option("prefs", download_option)
            chrome_options.add_argument("--disable-gpu")
            chrome_options.add_argument("--disable-extensions")
            chrome_options.add_argument("--window-size=1920,1080")
            chrome_driver = webdriver.Chrome(options=chrome_options)
            run_tests(driver=chrome_driver, base_url=base_url, email=user_email, password=user_password, webdriver_start_time_filename=webdriver_start_time_filename, donwload_path=donwload_path)
            
            firefox_options = FirefoxOptions()
            firefox_options.add_argument('--width=1920')
            firefox_options.add_argument('--height=1080')
            firefox_options.set_preference("browser.download.alwaysOpenPanel", False)
            firefox_options.set_preference("browser.download.folderList", 2)
            firefox_options.set_preference("browser.download.manager.showWhenStarting", False)
            firefox_options.set_preference("browser.download.dir", donwload_path)
            firefox_options.set_preference("browser.helperApps.neverAsk.saveToDisk", "application/x-gzip")
            firefox_driver = webdriver.Firefox(options=firefox_options, service=FirefoxService(GeckoDriverManager().install()))
            run_tests(driver=firefox_driver, base_url=base_url, email=user_email, password=user_password, webdriver_start_time_filename=webdriver_start_time_filename, donwload_path=donwload_path)
        case _:
            print("No valid browser type supplied")
            exit(1)

def generate_logs(webdriver_start_time_filename, start_time_actual, start_time_lower_bound, start_time_upper_bound):
    end_time_actual = datetime.utcnow()
    end_time_lower_bound = datetime.utcnow() - timedelta(seconds=30)
    end_time_upper_bound = datetime.utcnow() + timedelta(seconds=30)

    with open(webdriver_start_time_filename, 'w') as f:
        json.dump({
            'start_time_actual' : start_time_actual.isoformat(),
            'start_time_lower_bound': start_time_lower_bound.isoformat(),
            'start_time_upper_bound': start_time_upper_bound.isoformat(),
            'end_time_actual': end_time_actual.isoformat(),
            'end_time_lower_bound': end_time_lower_bound.isoformat(),
            'end_time_upper_bound': end_time_upper_bound.isoformat(),
        }, f)

def run_tests(driver: WebDriver, base_url: str, email: str, password: str, webdriver_start_time_filename: str | None, donwload_path: str):
    try:
        start_time_actual = datetime.utcnow()
        start_time_lower_bound = datetime.utcnow() - timedelta(seconds=30)
        start_time_upper_bound = datetime.utcnow() + timedelta(seconds=30)

        driver.get(base_url)
        driver.implicitly_wait(10)

        sign_in(driver, email, password)
        enter_geneLens(driver)

        survival_search_1(driver)
        reset_geneLens(driver, base_url)

        survival_search_2(driver, donwload_path)
        reset_geneLens(driver, base_url)

        survival_search_3(driver)
        reset_geneLens(driver, base_url)

        survival_search_4(driver)
        reset_geneLens(driver, base_url)

        heatmap_search_1(driver)
        
        driver.quit()
        generate_logs(webdriver_start_time_filename, start_time_actual, start_time_lower_bound, start_time_upper_bound)
    except Exception:
        print(traceback.format_exc())
        generate_logs(webdriver_start_time_filename, start_time_actual, start_time_lower_bound, start_time_upper_bound)
        driver.quit()
        exit(1)


def sign_in(driver: WebDriver, email: str, password: str):
    profile_menu_button = driver.find_element(by=By.ID, value="profile-menu")
    profile_menu_button.click()

    input_username = driver.find_element(by=By.NAME, value="identifier")
    input_username.send_keys(email)

    input_password = driver.find_element(by=By.NAME, value="credentials.passcode")
    input_password.send_keys(password)

    submit_button = driver.find_element(by=By.CLASS_NAME, value="button-primary")
    submit_button.click()

def enter_geneLens(driver: WebDriver):
    genelens_button = driver.find_element(by=By.ID, value="genelens")
    driver.execute_script(CLICK, genelens_button)

def reset_geneLens(driver: WebDriver, base_url: str):
    driver.get(base_url + "/genelens")

# This function makes sure the survival search has been completed before continuing
# on with the rest of the test. The unconventional pattern is necessary because
# on occasion, the search completes before the driver tries to find the loading
# icon, causing a NoSuchElementException to be thrown. By catching and passing
# that error, the desired effect is achieved.
def wait_for_search(driver: WebDriver):
    try:
        search_indicator = driver.find_element(By.ID, value="survival-search-indicator")
        WebDriverWait(driver, 10).until_not(EC.invisibility_of_element(search_indicator))
    except NoSuchElementException as e:
        pass

def run_gene_search(driver: WebDriver, search_box_index: int, search: str):
    search_box = driver.find_elements(by=By.ID, value="gene-selector")[search_box_index]
    search_box.send_keys(search)

    result_container = driver.find_element(by=By.ID, value="search-result-container")
    groups = result_container.find_elements(by=By.XPATH, value="//div[contains(@id, '-group')]")
    search_results = {}

    for group in groups:
        group_name = group.get_attribute("id")
        genes = group.find_elements(by=By.TAG_NAME, value="li")
        search_results[group_name] = [{"text": gene.text, "element": gene} for gene in genes]

    return search_results

# Primary Gene Only
def survival_search_1(driver: WebDriver):
    ar_search = run_gene_search(driver, 0, "AR")
    ar_search["symbol-group"][0]["element"].click()
    assert len(ar_search) > 0

    wait_for_search(driver)

    filter_toggle = driver.find_element(by=By.ID, value="table_e-toggle")
    filter_toggle.click()

    survivals = driver.find_elements(by=By.CLASS_NAME, value="MuiDataGrid-row")
    assert len(survivals) >= 3

    show_plots_button = survivals[2].find_element(by=By.CLASS_NAME, value="MuiButton-root")
    driver.execute_script(SCROLL_TO, show_plots_button)
    show_plots_button.click()

    charts = driver.find_elements(by=By.CLASS_NAME, value="react-pdf__Page__canvas")
    assert len(charts) == 1

def survival_search_2(driver: WebDriver, download_path: str):
    pcdha1_search = run_gene_search(driver, 0, "pcdha")
    pcdha1_search["symbol-group"][0]["element"].click()

    mmab_search = run_gene_search(driver, 1, "MMA")
    mmab_search["symbol-group"][1]["element"].click()

    search_button = driver.find_element(by=By.ID, value="survival-search-button")
    search_button.click()

    wait_for_search(driver)

    csv_download_button = driver.find_elements(By.ID, value="csv-download-button")[1]
    driver.execute_script(SCROLL_TO, csv_download_button)
    csv_download_button.click()

    mutated_table = driver.find_element(by=By.ID, value="table_m")
    survivals = mutated_table.find_elements(by=By.CLASS_NAME, value="MuiDataGrid-row")
    assert len(survivals) > 0

    show_plots_button = survivals[0].find_element(by=By.CLASS_NAME, value="MuiButton-root")
    driver.execute_script(SCROLL_TO, show_plots_button)
    show_plots_button.click()

    charts = driver.find_elements(by=By.CLASS_NAME, value="react-pdf__Page__canvas")
    assert len(charts) == 5

    with open(f'{download_path}/GeneLens.csv') as f:
        lines = f.readlines()
        header = lines[0].strip().replace('\ufeff', '')
        assert len(lines) == 3
        assert header == "'gene_e';'gene_m';'indication';'type';'p';'stat';'n';'n_mut';'id'"

def survival_search_3(driver: WebDriver):
    zzz3_search = run_gene_search(driver, 0, "zzz3")
    zzz3_search["symbol-group"][0]["element"].click()

    indication_selector = driver.find_element(by=By.ID, value="indication-selector")
    indication_selector.send_keys("BRCA")

    search_button = driver.find_element(by=By.ID, value="survival-search-button")
    search_button.click()

    wait_for_search(driver)

    expressed_table = driver.find_element(by=By.ID, value="table_e")
    expressed_survivals = expressed_table.find_elements(by=By.CLASS_NAME, value="MuiDataGrid-row")
    assert len(expressed_survivals) == 0

    mutated_table = driver.find_element(by=By.ID, value="table_m")
    mutated_survivals = mutated_table.find_elements(by=By.CLASS_NAME, value="MuiDataGrid-row")
    assert len(mutated_survivals) > 0

    show_plots_button = mutated_survivals[0].find_element(by=By.CLASS_NAME, value="MuiButton-root")
    driver.execute_script(SCROLL_TO, show_plots_button)
    show_plots_button.click()

    charts = driver.find_elements(by=By.CLASS_NAME, value="react-pdf__Page__canvas")
    assert len(charts) == 5
    

def survival_search_4(driver: WebDriver):
    sox5_search = run_gene_search(driver, 0, "sox5")
    sox5_search["symbol-group"][0]["element"].click()
    assert len(sox5_search) == 3

    or10z1_search = run_gene_search(driver, 1, "or10z1")
    or10z1_search["symbol-group"][0]["element"].click()

    indication_selector = driver.find_element(by=By.ID, value="indication-selector")
    indication_selector.send_keys("LUSC")

    search_button = driver.find_element(by=By.ID, value="survival-search-button")
    search_button.click()

    wait_for_search(driver)

    survivals = driver.find_elements(by=By.CLASS_NAME, value="MuiDataGrid-row")
    assert len(survivals) > 0

    show_plots_button = survivals[0].find_element(by=By.CLASS_NAME, value="MuiButton-root")
    driver.execute_script(SCROLL_TO, show_plots_button)
    show_plots_button.click()

    charts = driver.find_elements(by=By.CLASS_NAME, value="react-pdf__Page__canvas")
    assert len(charts) == 5

    webdriver.ActionChains(driver).send_keys(Keys.ESCAPE).perform()

    indication_selector_parent = indication_selector.find_element(by=By.XPATH, value="./..")
    clear_indication_button = indication_selector_parent.find_element(by=By.CLASS_NAME, value="MuiAutocomplete-endAdornment")
    clear_indication_button.click()

    wait_for_search(driver)

    expressed_table = driver.find_element(by=By.ID, value="table_e")
    n_mut_header = expressed_table.find_element(by=By.XPATH, value="//div[@data-field='n_mut']")
    n_mut_header.click()

    stat_header = expressed_table.find_element(by=By.XPATH, value="//div[@data-field='stat']")
    webdriver.ActionChains(driver) \
        .key_down(Keys.CONTROL) \
        .click(stat_header) \
        .key_up(Keys.CONTROL) \
        .perform()

    url = urllib.parse.unquote(driver.current_url, encoding='utf-8', errors='replace')
    assert '[{"field":"n_mut","sort":"asc"},{"field":"stat","sort":"asc"}]' in url

def heatmap_search_1(driver: WebDriver):
    _ = run_gene_search(driver, 0, "BMP1")
    search_button = driver.find_element(by=By.ID, value="survival-search-button")
    search_button.click()

    wait_for_search(driver)

    heatmap_div = driver.find_element(by=By.ID, value="BMP1-heatmap")
    driver.execute_script(SCROLL_TO, heatmap_div)

if __name__ == "__main__":
    print(sys.argv)
    parser = argparse.ArgumentParser()
    parser.add_argument
    parser.add_argument('--project_arn', required=False, help='The AWS TestGrid project ARN (Only required if running in Device Farm)')
    parser.add_argument('--user_email', required=True, help='Test User\'s Email Address')
    parser.add_argument('--user_password', required=True, help='Test User\'s Password')
    parser.add_argument('--base_url', required=True, help='Base URL for GeneLens')
    parser.add_argument('--browser_type', required=True, help='Which browser type to test [chrome|local]', choices=['chrome','firefox','internal'])
    parser.add_argument('--webdriver_start_time_filename', required=False, help='File for recording start time of the webdriver session.')
    parser.add_argument('--download_path', required=True, help='File Path for the location of downloads')
    args = parser.parse_args()
    main(
        args.project_arn,
        args.user_email,
        args.user_password,
        args.base_url,
        args.browser_type,
        args.webdriver_start_time_filename,
        args.download_path
    )
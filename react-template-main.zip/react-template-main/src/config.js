const config = {
  oidc: {
    issuer: process.env.REACT_APP_OKTA_ISSUER,
    clientId: process.env.REACT_APP_OKTA_CLIENT_ID,
    scopes: ["openid", "profile", "email", "offline_access"],
    redirectUri: `${window.location.origin}/login/callback`,
  },
  widget: {
    issuer: process.env.REACT_APP_OKTA_ISSUER,
    clientId: process.env.REACT_APP_OKTA_CLIENT_ID,
    redirectUri: `${window.location.origin}/login/callback`,
    scopes: ["openid", "profile", "email", "offline_access"],
    logo: "https://www.exelixis.com/wp-content/uploads/2023/01/Exelixis-Logo-2023.png",
    logoText: "Exelixis EBIP",
    brandName: "Exelixis",
  },
  version: "v1.11.0",
};

export default config;

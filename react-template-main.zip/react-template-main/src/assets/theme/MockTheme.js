import React from "react";
import { ThemeProvider } from "@mui/system";
import theme from "assets/theme";

export default function MockTheme(props) {
  const { children } = props;
  return <ThemeProvider theme={theme}>{children}</ThemeProvider>
}

/* eslint-disable  */
/**
=========================================================
* Material Dashboard 2 React - v2.1.0
=========================================================

* Product Page: https://www.creative-tim.com/product/material-dashboard-react
* Copyright 2022 Creative Tim (https://www.creative-tim.com)

Coded by www.creative-tim.com

 =========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
*/

import { useEffect } from "react";

// react-router-dom components
import { useLocation } from "react-router-dom";

// prop-types is a library for typechecking of props.
import PropTypes from "prop-types";

// Material Dashboard 2 React components
import MDBox from "components/MDBox";
import Footer from "components/Footer";

// Material Dashboard 2 React context
import { useMaterialUIController, setLayout } from "context";
import AuthSidenav from "components/custom/AuthSidenav";
import DashboardNavbar from "components/DashboardNavbar";

function DashboardLayout(props) {
  const { headerTitle, headerButtons, children } = props;
  const [controller, dispatch] = useMaterialUIController();
  const { miniSidenav } = controller;
  const { pathname } = useLocation();

  useEffect(() => {
    setLayout(dispatch, "dashboard");
  }, [dispatch, pathname]);

  return (
    <>
      <AuthSidenav zIndex={0} />
      <MDBox
        minHeight="100vh"
        sx={({ breakpoints, transitions, functions: { pxToRem } }) => ({
          px: 2,
          position: "relative",
          [breakpoints.up("xl")]: {
            marginLeft: miniSidenav ? pxToRem(120) : pxToRem(274),
            transition: transitions.create(["margin-left", "margin-right"], {
              easing: transitions.easing.easeInOut,
              duration: transitions.duration.standard,
            }),
          },
        })}
      >
        {/* <Header title={headerTitle} buttons={headerButtons} /> */}
        <DashboardNavbar title={headerTitle} buttons={headerButtons} />
        {children}
        <Footer />
      </MDBox>
    </>
  );
}

DashboardLayout.defaultProps = {
  headerButtons: [],
};

// Typechecking props for the DashboardLayout
DashboardLayout.propTypes = {
  children: PropTypes.node.isRequired,
  headerTitle: PropTypes.string.isRequired,
  headerButtons: PropTypes.arrayOf(
    PropTypes.shape({
      icon: PropTypes.node.isRequired,
      effect: PropTypes.func.isRequired,
      toolTip: PropTypes.string.isRequired, // Add key for mapped component
    })
  ),
};

export default DashboardLayout;

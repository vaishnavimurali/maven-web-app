import React from "react";
import { Menu, MenuItem, Box, Tooltip, IconButton, Typography, Icon } from "@mui/material";
import MDTypography from "components/MDTypography";
// import { useOktaAuth } from "@okta/okta-react";
import { useMaterialUIController } from "context";
import { useOktaAuth } from "@okta/okta-react";
import { toRelativeUrl } from "@okta/okta-auth-js";
import { navbarIconButton } from "./styles";

// eslint-disable-next-line react/prop-types
function ProfileMenu(props) {
  // eslint-disable-next-line react/prop-types
  const { iconsStyle } = props;
  const [anchorElUser, setAnchorElUser] = React.useState(null);
  const { oktaAuth } = useOktaAuth();

  const [controller] = useMaterialUIController();
  const { authState, userInfo } = controller;

  const handleOpenUserMenu = (event) => {
    setAnchorElUser(event.currentTarget);
  };
  const handleCloseUserMenu = () => {
    setAnchorElUser(null);
  };

  const handleLogout = async () =>
    oktaAuth.signOut({ postLogoutRedirectUri: window.location.origin });
  const handleLogin = async () => {
    const originalUri = toRelativeUrl(window.location.href, window.location.origin);
    oktaAuth.setOriginalUri(originalUri);
    oktaAuth.signInWithRedirect();
  };

  const settings = [{ title: "Logout", effect: handleLogout }];
  return (
    <Box>
      <Tooltip title={authState?.isAuthenticated ? "Settings" : "Log In"}>
        <IconButton
          fontSize="large"
          size="large"
          centerRipple
          color="inherit"
          sx={navbarIconButton}
          aria-controls="notification-menu"
          aria-haspopup="true"
          variant="contained"
          id="profile-menu"
          onClick={authState?.isAuthenticated ? handleOpenUserMenu : handleLogin}
        >
          {authState?.isAuthenticated && userInfo ? (
            <MDTypography sx={iconsStyle} color="inherit" variant="h4" noWrap>
              {userInfo.given_name[0] + userInfo.family_name[0]}
            </MDTypography>
          ) : (
            <Icon sx={iconsStyle} color="inherit">
              login
            </Icon>
          )}
        </IconButton>
      </Tooltip>
      <Menu
        sx={{ mt: "45px" }}
        id="menu-appbar"
        anchorEl={anchorElUser}
        anchorOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
        keepMounted
        transformOrigin={{
          vertical: -25,
          horizontal: 10,
        }}
        open={Boolean(anchorElUser)}
        onClose={handleCloseUserMenu}
      >
        {settings.map((setting) => (
          <MenuItem key={setting.title} onClick={setting.effect}>
            <Typography textAlign="center">{setting.title}</Typography>
          </MenuItem>
        ))}
      </Menu>
    </Box>
  );
}

export default ProfileMenu;

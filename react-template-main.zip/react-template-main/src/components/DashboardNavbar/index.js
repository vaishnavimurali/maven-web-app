/**
=========================================================
* Material Dashboard 2 React - v2.2.0
=========================================================

* Product Page: https://www.creative-tim.com/product/material-dashboard-react
* Copyright 2023 Creative Tim (https://www.creative-tim.com)

Coded by www.creative-tim.com

 =========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
*/

import React from "react";

// prop-types is a library for typechecking of props.
import PropTypes from "prop-types";

// @material-ui core components
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Icon from "@mui/material/Icon";
import { Tooltip } from "@mui/material";

import typography from "assets/theme/base/typography";
import typographyDark from "assets/theme-dark/base/typography";

// Material Dashboard 2 React components
import MDBox from "components/MDBox";
import MDTypography from "components/MDTypography";

// Material Dashboard 2 React example components

// Custom styles for DashboardNavbar
import {
  navbar,
  navbarContainer,
  navbarIconButton,
  navbarMobileMenu,
} from "components/DashboardNavbar/styles";

// Material Dashboard 2 React context
import { useMaterialUIController, setMiniSidenav, setDarkMode } from "context";
import ProfileMenu from "./ProfileMenu";

function DashboardNavbar(props) {
  const { title, buttons, absolute } = props;
  const [controller, dispatch] = useMaterialUIController();
  const { authState, miniSidenav, darkMode } = controller;
  const { size } = darkMode ? typographyDark : typography;
  const light = darkMode;

  const handleMiniSidenav = () => setMiniSidenav(dispatch, !miniSidenav);

  // Styles for the navbar icons
  const iconsStyle = ({ palette: { dark, white } }) => ({
    color: () => {
      const colorValue = light || darkMode ? white.main : dark.main;

      return colorValue;
    },
  });

  return (
    <AppBar
      position="sticky"
      color="inherit"
      sx={(theme) => navbar(theme, { transparentNavbar: false, absolute, light, darkMode })}
    >
      <Toolbar sx={(theme) => navbarContainer(theme)}>
        <MDBox
          display="flex"
          justifyContent="center"
          alignItems="center"
          flexWrap="wrap"
          fontSize={size.sm}
          px={1.5}
        >
          <MDTypography variant="h2" fontWeight="regular">
            {title}
          </MDTypography>
        </MDBox>
        <MDBox
          component="ul"
          sx={() => ({
            display: "flex",
            flexWrap: "wrap",
            alignItems: "center",
            justifyContent: "center",
            listStyle: "none",
            mt: 0,
            mb: 0,
            p: 0,
          })}
        >
          {buttons.map((button) => (
            <Tooltip title={button.toolTip} key={`button_${button.toolTip}`}>
              <IconButton
                fontSize="large"
                size="large"
                centerRipple
                color="inherit"
                sx={navbarIconButton}
                aria-controls="notification-menu"
                aria-haspopup="true"
                variant="contained"
                onClick={button.effect}
              >
                <Icon sx={iconsStyle} baseClassName="material-icons-outlined">
                  {button.icon}
                </Icon>
              </IconButton>
            </Tooltip>
          ))}
          {authState?.isAuthenticated && (
            <Tooltip title="Feedback" key="button_Feedback">
              <IconButton
                fontSize="large"
                size="large"
                centerRipple
                color="inherit"
                sx={navbarIconButton}
                aria-controls="notification-menu"
                aria-haspopup="true"
                variant="contained"
                onClick={() => window.open("/feedback", "_blank", "noreferrer")}
              >
                <Icon sx={iconsStyle} baseClassName="material-icons-outlined">
                  feedback
                </Icon>
              </IconButton>
            </Tooltip>
          )}
          <Tooltip title={darkMode ? "Light Mode" : "Dark Mode"} key="button_dark_mode">
            <IconButton
              fontSize="large"
              size="large"
              centerRipple
              color="inherit"
              sx={navbarIconButton}
              aria-controls="notification-menu"
              aria-haspopup="true"
              variant="contained"
              onClick={() => setDarkMode(dispatch, !darkMode)}
            >
              <Icon sx={iconsStyle}>{darkMode ? "light_mode" : "dark_mode"}</Icon>
            </IconButton>
          </Tooltip>
          <ProfileMenu iconsStyle={iconsStyle} />
          <Tooltip
            title={miniSidenav ? "Open Sidenav" : "Close Sidenav"}
            key="button_toggle_sidenav"
          >
            <IconButton
              fontSize="large"
              size="large"
              centerRipple
              color={light ? "white" : "inherit"}
              sx={navbarMobileMenu}
              aria-controls="notification-menu"
              aria-haspopup="true"
              variant="contained"
              onClick={handleMiniSidenav}
            >
              <Icon sx={iconsStyle}>{miniSidenav ? "menu_open" : "menu"}</Icon>
            </IconButton>
          </Tooltip>
        </MDBox>
      </Toolbar>
    </AppBar>
  );
}

// Setting default values for the props of DashboardNavbar
DashboardNavbar.defaultProps = {
  absolute: false,
  buttons: [],
};

// Typechecking props for the DashboardNavbar
DashboardNavbar.propTypes = {
  absolute: PropTypes.bool,
  title: PropTypes.string.isRequired,
  buttons: PropTypes.arrayOf(
    PropTypes.shape({
      icon: PropTypes.string.isRequired,
      effect: PropTypes.func.isRequired,
      toolTip: PropTypes.string.isRequired, // Add key for mapped component
    })
  ),
};

export default DashboardNavbar;

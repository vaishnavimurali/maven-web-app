import React from "react";
import PropTypes from "prop-types";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";

const indications = [
  "BRCA",
  "CESC",
  "COAD",
  "DBLC",
  "GBM",
  "HNSC",
  "KIRC",
  "KIRP",
  "LGG",
  "LIHC",
  "LUAD",
  "LUSC",
  "OV",
  "PRAD",
  "READ",
  "SARC",
  "SKCM",
];

function IndicationSelector(props) {
  const { value, setValue, label, style } = props;

  return (
    <Autocomplete
      autoSelect
      freeSolo
      value={value}
      onChange={(event, newValue) => {
        setValue(newValue);
      }}
      id="indication-selector"
      options={indications}
      style={style}
      renderInput={(params) => <TextField {...params} label={label} />}
    />
  );
}
IndicationSelector.propTypes = {
  value: PropTypes.string,
  setValue: PropTypes.func.isRequired,
  label: PropTypes.string,
  searchNow: PropTypes.func,
  // eslint-disable-next-line react/forbid-prop-types
  style: PropTypes.object,
};
IndicationSelector.defaultProps = {
  value: null,
  label: "",
  searchNow: () => {},
  style: {},
};

export default IndicationSelector;

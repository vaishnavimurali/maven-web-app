import React from "react";

import Sidenav from "components/Sidenav";
import { useMaterialUIController } from "context";
import brand from "assets/images/exelixis-logo.png";
import routes from "routes";

function AuthSidenav() {
  const [controller] = useMaterialUIController();
  const { sidenavColor, authState } = controller;

  function getSidebarRoutes(allRoutes, authenticatedState) {
    return authenticatedState ? allRoutes : allRoutes.filter((route) => route.secure === false);
  }

  if (!authState) {
    return (
      <Sidenav
        color={sidenavColor}
        brand={brand}
        brandName="GeneLens (beta)"
        routes={getSidebarRoutes(routes, false)}
      />
    );
  }

  return (
    <Sidenav
      color={sidenavColor}
      brand={brand}
      brandName="GeneLens (beta)"
      routes={getSidebarRoutes(routes, authState.isAuthenticated)}
    />
  );
}

export default AuthSidenav;

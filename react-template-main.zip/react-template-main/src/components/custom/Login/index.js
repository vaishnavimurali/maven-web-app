import React from "react";
import { useOktaAuth } from "@okta/okta-react";
import Loading from "components/custom/Loading";

function Login() {
  const { oktaAuth } = useOktaAuth();

  oktaAuth.signInWithRedirect();
  return <Loading />;
}

export default Login;

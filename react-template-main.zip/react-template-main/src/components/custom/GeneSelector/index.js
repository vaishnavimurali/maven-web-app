/* eslint-disable no-prototype-builtins */
/* eslint-disable react/require-default-props */
/* eslint-disable react/jsx-props-no-spreading */
import React, { useEffect, useMemo, useState } from "react";
import PropTypes from "prop-types";
// import TextField from "@mui/material/TextField";
import Autocomplete, { autocompleteClasses } from "@mui/material/Autocomplete";
import { Oval } from "react-loading-icons";
import Popper from "@mui/material/Popper";
import { styled } from "@mui/material/styles";
import { VariableSizeList } from "react-window";
import typography from "assets/theme/base/typography";
import { debounce } from "@mui/material/utils";
import { GeneSelectorSearch, GetGeneFromExactSearch } from "apiWrapper";
import MDBox from "components/MDBox";
import MDInput from "components/MDInput";
import Highlighter from "react-highlight-words";
import MDTypography from "components/MDTypography";
import { useMaterialUIController } from "context";

const LISTBOX_PADDING = 2; // px

export default function GeneSelector(_props) {
  const { value, setValue, label, _style } = _props;
  const [controller] = useMaterialUIController();
  const { darkMode } = controller;

  const [open, setOpen] = useState(false);
  const [inputValue, setInputValue] = useState(value?.symbol || "");
  const [options, setOptions] = useState([]);
  const [loading, setLoading] = useState(false);

  /* eslint-disable react/prop-types */
  function renderRow(props) {
    const { data, index, style } = props;
    const dataSet = data[index];

    const { size } = typography;
    const inlineStyle = {
      ...style,
      top: style.top + LISTBOX_PADDING,
    };

    const method = dataSet[1].method;
    dataSet[0]["aria-selected"] = false;

    const highlightStyle = {
      color: darkMode ? "#ffffff" : "text",
      backgroundColor: darkMode ? "#fc4c01aa" : "#fc4c0155",
    };

    return (
      <MDBox
        component="li"
        {...dataSet[0]}
        style={inlineStyle}
        display="flex"
        flexDirection="column"
        alignItems="left"
      >
        <MDBox
          color="text"
          fontSize={size.sm}
          display="flex"
          width="100%"
          justifyContent="space-between"
        >
          <MDTypography variant="p" fontWeight="regular" justifySelf="left">
            {method === "symbol" ? (
              <Highlighter
                highlightStyle={highlightStyle}
                searchWords={[inputValue]}
                textToHighlight={dataSet[1].symbol}
              />
            ) : (
              dataSet[1].symbol
            )}
            {method === "alias" && (
              <Highlighter
                highlightStyle={highlightStyle}
                searchWords={[inputValue]}
                textToHighlight={`  (${dataSet[1].alias})`}
              />
            )}
          </MDTypography>
          <MDTypography variant="p" fontWeight="light" color="text" justifySelf="right">
            {dataSet[1].hgnc_id.split(":")[1]}
          </MDTypography>
        </MDBox>
        <MDTypography
          width="100%"
          variant="p"
          fontSize={size.xs}
          fontWeight="light"
          color="text"
          justifySelf="left"
        >
          {method === "name" ? (
            <Highlighter
              highlightStyle={highlightStyle}
              searchWords={[inputValue]}
              textToHighlight={`${dataSet[1].name.substring(0, 82)}${
                dataSet[1].name.length <= 82 ? "" : "..."
              }`}
            />
          ) : (
            `${dataSet[1].name.substring(0, 82)}${dataSet[1].name.length <= 82 ? "" : "..."}`
          )}
        </MDTypography>
      </MDBox>
    );
  }
  /* eslint-enable react/prop-types */

  const OuterElementContext = React.createContext({});

  const OuterElementType = React.forwardRef((props, ref) => {
    const outerProps = React.useContext(OuterElementContext);
    return <div ref={ref} {...props} {...outerProps} />;
  });

  // Adapter for react-window
  const ListboxComponent = React.forwardRef((props, ref) => {
    const { children, ...other } = props;
    const itemData = {};
    children.forEach((group) => {
      itemData[group.group] = {
        children: group.children,
        count: group.children.length,
      };
    });

    const { size } = typography;

    const itemSize = 48;

    const getChildSize = (child) => itemSize * (child[1].name.length <= 40 ? 1.25 : 1.5);

    const listThreshold = 12 / Object.keys(itemData).length;

    const getHeight = (group) => {
      if (itemData[group].count > listThreshold) {
        return listThreshold * itemSize;
      }
      return itemData[group].children.map(getChildSize).reduce((a, b) => a + b, 0);
    };

    const searchGroup = (group) => (
      <div key={`${group}-group`} id={`${group}-group`}>
        <MDBox
          color="text"
          fontSize={size.sm}
          display="flex"
          width="100%"
          justifyContent="space-between"
          bgColor="light"
          sx={{ pl: 0.75, pt: 0.75, bgColor: "text", borderRadius: 2 }}
        >
          <MDTypography variant="h5" fontWeight="regular" color="text" justifySelf="left">
            Gene {group.charAt(0).toUpperCase() + group.slice(1)}
          </MDTypography>
        </MDBox>
        <VariableSizeList
          itemData={itemData[group].children}
          height={getHeight(group) + 2 * LISTBOX_PADDING}
          width="100%"
          outerElementType={OuterElementType}
          innerElementType="ul"
          itemSize={(index) => getChildSize(itemData[group].children[index])}
          overscanCount={5}
          itemCount={itemData[group].count}
        >
          {renderRow}
        </VariableSizeList>
      </div>
    );

    return (
      <div ref={ref} id="search-result-container">
        <OuterElementContext.Provider value={other}>
          {Object.keys(itemData).map((group) => searchGroup(group))}
        </OuterElementContext.Provider>
      </div>
    );
  });

  ListboxComponent.propTypes = {
    // eslint-disable-next-line react/forbid-prop-types
    children: PropTypes.array,
  };

  const StyledPopper = styled(Popper)({
    [`& .${autocompleteClasses.listbox}`]: {
      boxSizing: "border-box",
      "& ul": {
        padding: 0,
        margin: 0,
      },
    },
  });

  const getSymbols = useMemo(
    () =>
      debounce((search, callback) => {
        GeneSelectorSearch(search).then(callback);
      }, 400),
    []
  );

  useEffect(() => {
    let active = true;
    const search = inputValue.trim();
    if (search.length < 2) {
      setOptions([]);
      setLoading(false);
      return undefined;
    }

    setLoading(true);
    getSymbols(search, (genes) => {
      if (active) {
        setOptions(genes);
        setLoading(false);
      }
    });

    return () => {
      active = false;
    };
  }, [inputValue, getSymbols]);

  useEffect(() => {
    if (!value) setInputValue("");
    else if (value.symbol !== inputValue) setInputValue(value.symbol);
  }, [value]);

  const HandleChange = async (event, newValue, reason, source) => {
    if (loading && source === "onChange" && reason !== "blur") return;

    // Check search box for desired search term
    const newSearch =
      source === "onInputChange" || typeof newValue === "object" ? inputValue : newValue;

    if (source === "onInputChange" || reason === "createOption") {
      const gene = await GetGeneFromExactSearch(newSearch);
      if (gene) {
        setValue(gene);
        return;
      }
      setOpen(true);
      return;
    }

    // Clicked off form -> set nothing and return
    if (reason === "blur" && !event.relatedTarget) return;

    if (!loading && typeof newValue === "object") {
      setValue(newValue);
      return;
    }

    // Attempt to set value based on search
    // order = Symbol -> Alias/Prev Symbol -> Name
    if (!value || value?.symbol !== newSearch) {
      const gene = await GetGeneFromExactSearch(newSearch);
      if (gene) {
        setValue(gene);
        return;
      }

      const genes = await GeneSelectorSearch(newSearch);
      if (genes.length > 0) {
        setValue(genes[0]);
        return;
      }
    }
    setOpen(reason !== "blur");
  };

  return (
    <Autocomplete
      id="gene-selector"
      name={label}
      value={value}
      onChange={async (event, newValue, reason) => {
        HandleChange(event, newValue, reason, "onChange");
      }}
      inputValue={inputValue}
      onInputChange={(event, newInputValue, reason) => {
        if (
          event &&
          event.type === "keydown" &&
          (event.code === "Enter" || event.code === "NumpadEnter") &&
          loading
        ) {
          HandleChange(event, newInputValue, reason, "onInputChange");
        }
        if (!event || reason === "reset") {
          return;
        }
        if (newInputValue.match(/[{}[\]()\\|"]|(\.\.)/)) return;
        setInputValue(newInputValue);
      }}
      autoHighlight
      autoSelect
      freeSolo
      filterOptions={(x) => x}
      open={open && (options.length > 0 || loading)}
      onFocus={() => {
        if (options.length > 0 || loading) setOpen(true);
      }}
      onBlur={() => {
        setOpen(false);
      }}
      onOpen={() => {
        setOpen(true);
      }}
      onClose={() => {
        setOpen(false);
      }}
      disableListWrap
      groupBy={(option) => option.method}
      PopperComponent={StyledPopper}
      ListboxComponent={ListboxComponent}
      options={options}
      loading={loading}
      getOptionLabel={(option) => (option?.symbol ? option.symbol : "")}
      style={_style}
      renderInput={(params) => (
        <MDInput
          {...params}
          label={label}
          InputProps={{
            ...params.InputProps,
            endAdornment: (
              <>
                {loading ? <Oval width="30" height="30" stroke="#fc4c01" /> : null}
                {params.InputProps.endAdornment}
              </>
            ),
          }}
        />
      )}
      renderOption={(props, option, state) => [props, option, state.index]}
      // TODO: Post React 18 update - validate this conversion, look like a hidden bug
      renderGroup={(params) => params}
    />
  );
}
GeneSelector.propTypes = {
  // eslint-disable-next-line react/forbid-prop-types
  value: PropTypes.object,
  setValue: PropTypes.func.isRequired,
  label: PropTypes.string,
  searchNow: PropTypes.func,
  // eslint-disable-next-line react/forbid-prop-types
  _style: PropTypes.object,
};
GeneSelector.defaultProps = {
  value: {},
  label: "",
  searchNow: () => {},
  _style: {},
};

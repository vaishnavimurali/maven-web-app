import { Routes, Route, Navigate } from "react-router-dom";
import routes from "routes";
import Loading from "components/custom/Loading";
import Login from "components/custom/Login";
import { LoginCallback } from "@okta/okta-react";
import RequiredAuth from "components/custom/SecureRoute";

export default function AppRoutes() {
  const getOpenRoutes = (allRoutes) =>
    allRoutes.map((route) => {
      if (route.route && !route.secure) {
        return <Route exact path={route.route} element={route.component} key={route.key} />;
      }

      return null;
    });

  const getSecureRoutes = (allRoutes) =>
    allRoutes.map((route) => {
      if (route.route && route.secure) {
        return (
          <Route path={route.route} key={route.key} element={<RequiredAuth />}>
            <Route path="" element={route.component} />
          </Route>
        );
      }

      return null;
    });

  return (
    <Routes>
      <Route path="login/callback" element={<LoginCallback loadingElement={<Loading />} />} />
      <Route path="" element={<Navigate to="/home" />} />
      <Route path="login" element={<Login />} />
      {getOpenRoutes(routes)}
      {getSecureRoutes(routes)}
    </Routes>
  );
}

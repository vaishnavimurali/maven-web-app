import { EventSourcePolyfill } from "event-source-polyfill";
import { convertXML } from "simple-xml-to-json";

const apiURL = process.env.REACT_APP_ARETI_API
  ? process.env.REACT_APP_ARETI_API
  : "https://payload-backend.dev.genelens.aws-exelixis.com";

export async function GetGeneFromSymbol(symbol) {
  if (!symbol) return null;
  // eslint-disable-next-line react/destructuring-assignment
  let search = symbol.toUpperCase();
  if (/C[X0-9]+ORF/.test(search)) {
    search = search.replace("ORF", "orf");
  }
  const query = `{Hgnccsas(where:{symbol:{equals:"${search}"}},limit:1){docs{symbol,name,hgnc_id,entrez_id,alias_symbol,prev_symbol}}}`;
  return fetch(`${apiURL}/api/graphql`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ query }),
  })
    .then((resp) => resp.json())
    .then((json) => (json.data.Hgnccsas.docs[0] ? json.data.Hgnccsas.docs[0] : null));
}

export async function GetGeneFromAlias(alias) {
  if (!alias) return null;
  // eslint-disable-next-line react/destructuring-assignment
  const search = alias.toUpperCase().trim();

  const query = `{Hgnccsas(where:{OR:[{alias_symbol:{contains:"${search}"}}{prev_symbol:{contains:"${search}"}}]},limit:100){docs{symbol,name,hgnc_id,entrez_id,alias_symbol,prev_symbol}}}`;
  const gene = fetch(`${apiURL}/api/graphql?query=${query}`)
    .then((resp) => resp.json())
    .then((json) =>
      json.data.Hgnccsas.docs.reduce((aliasedGenes, foundGene) => {
        let aliases = foundGene.alias_symbol ? foundGene.alias_symbol.split("|") : [];
        aliases = aliases.concat(foundGene.prev_symbol ? foundGene.prev_symbol.split("|") : []);
        return [
          ...aliasedGenes,
          ...aliases.reduce((matchedAliases, currentAlias) => {
            if (currentAlias.toUpperCase() === search) {
              return [...matchedAliases, { ...foundGene }];
            }
            return matchedAliases;
          }, []),
        ];
      }, [])
    )
    .then((results) => (results.length > 0 ? results[0] : null));
  return gene;
}

export function GetGeneFromName(name) {
  if (!name) return null;
  // eslint-disable-next-line react/destructuring-assignment
  const search = name.toUpperCase().trim();

  const query = `{Hgnccsas(where:{name:{contains:"${search}"}},limit:100){docs{symbol,name,hgnc_id,entrez_id,alias_symbol,prev_symbol}}}`;
  const gene = fetch(`${apiURL}/api/graphql?query=${query}`)
    .then((resp) => resp.json())
    .then((json) => {
      const foundGene = json.data.Hgnccsas.docs.find((doc) => doc.name.toUpperCase() === search);
      return foundGene || null;
    });
  return gene;
}

export async function GetGeneFromExactSearch(search) {
  let gene = await GetGeneFromSymbol(search);
  if (gene) {
    return gene;
  }

  gene = await GetGeneFromAlias(search);
  if (gene) {
    return gene;
  }
  gene = await GetGeneFromName(search);
  if (gene) {
    return gene;
  }

  return null;
}

export async function GeneSelectorSearch(_search) {
  const search = _search.toUpperCase();

  const SymbolSearch = async (symbol) => {
    const query = `{Hgnccsas(where:{symbol:{contains:"${symbol}"}},sort:"symbol",limit:1000000){docs{symbol,name,hgnc_id,entrez_id,alias_symbol,prev_symbol}}}`;
    const genes = fetch(`${apiURL}/api/graphql?query=${query}`)
      .then((resp) => resp.json())
      .then((json) =>
        json.data.Hgnccsas.docs
          .reduce(
            ([startsWith, contains], gene) =>
              gene.symbol.toUpperCase().startsWith(search)
                ? [[...startsWith, gene], contains]
                : [startsWith, [...contains, gene]],
            [[], []]
          )
          .flat()
      )
      .then((results) => results.map((gene) => ({ ...gene, method: "symbol" })));
    return genes;
  };

  const AliasSearch = async (alias) => {
    const query = `{Hgnccsas(where:{OR:[{alias_symbol:{contains:"${alias}"}}{prev_symbol:{contains:"${alias}"}}]}limit:1000000){docs{symbol,name,hgnc_id,entrez_id,alias_symbol,prev_symbol}}}`;
    const genes = fetch(`${apiURL}/api/graphql?query=${query}`)
      .then((resp) => resp.json())
      .then((json) =>
        // Find all matching aliases and extract from list of aliases per gene
        json.data.Hgnccsas.docs.reduce((aliasedGenes, gene) => {
          let aliases = gene.alias_symbol ? gene.alias_symbol.split("|") : [];
          aliases = aliases.concat(gene.prev_symbol ? gene.prev_symbol.split("|") : []);
          return [
            ...aliasedGenes,
            ...aliases.reduce((acc, cur) => {
              if (!cur.toUpperCase().includes(alias)) {
                return acc;
              }
              return [...acc, { ...gene, alias: cur }];
            }, []),
          ];
        }, [])
      )
      // Sort all aliases beginning with aliases starting with the search term
      .then((aliasedGenes) =>
        aliasedGenes
          .reduce(
            ([startsWith, contains], gene) =>
              gene.alias.toUpperCase().startsWith(search)
                ? [[...startsWith, gene], contains]
                : [startsWith, [...contains, gene]],
            [[], []]
          )
          .map((l) => l.sort((a, b) => a.alias.localeCompare(b.alias)))
          .flat()
      )
      .then((results) => results.map((gene) => ({ ...gene, method: "alias" })));
    return genes;
  };

  const NameSearch = async (name) => {
    if (name.length < 4) return [];
    const query = `{Hgnccsas(where:{name:{contains: "${name}"}},sort:"name",limit: 1000000){docs{symbol,name,hgnc_id,entrez_id,alias_symbol,prev_symbol}}}`;
    const genes = fetch(`${apiURL}/api/graphql?query=${query}`)
      .then((resp) => resp.json())
      .then((json) => json.data.Hgnccsas.docs)
      .then((results) => results.map((gene) => ({ ...gene, method: "name" })));
    return genes;
  };

  const symbolSearch = SymbolSearch(search);
  const aliasSearch = AliasSearch(search);
  const nameSearch = NameSearch(search);
  return [...(await symbolSearch), ...(await aliasSearch), ...(await nameSearch)];
}

export async function GetSurvivals(primaryGene, secondaryGene, indication) {
  const QuerySurvivals = async (geneE, geneM, indicaiton) => {
    const where = `{
      ${geneE ? `gene_e: {equals: "${geneE}"}` : ""}
      ${geneM ? `gene_m: {equals: "${geneM}"}` : ""}
      ${indicaiton ? `indication: {equals: "${indicaiton}"}` : ""}
    }`;
    const query = `{Survivals(where:${where},limit:100000,sort:"-stat"){docs{gene_e,gene_m,indication,type,p,stat,n,n_mut,id}}}`;
    const survivals = fetch(`${apiURL}/api/graphql?query=${query}`)
      .then((resp) => resp.json())
      .then((json) => json.data.Survivals.docs);

    return survivals;
  };

  const survivals = [
    await QuerySurvivals(primaryGene, secondaryGene, indication),
    await QuerySurvivals(secondaryGene, primaryGene, indication),
  ];

  return survivals;
}

export function SurvivalPlotsSSE(survivalID) {
  return new EventSourcePolyfill(`${apiURL}/geneLens/survivalCharts/${survivalID}`);
}

export function GetReport(reportID) {
  const query = `{Report(id: "${reportID}") {title,description,report}}`;
  const report = fetch(`${apiURL}/api/graphql?query=${query}`)
    .then((resp) => resp.json())
    .then((json) => json.data.Report);

  return report;
}

export async function GetGeneSummary(geneID) {
  const url = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=gene&id=${geneID}`;
  return fetch(url)
    .then((response) => response.text())
    .then((data) => {
      const result = convertXML(data);
      return result[""].children[15].Summary.content;
    });
}
